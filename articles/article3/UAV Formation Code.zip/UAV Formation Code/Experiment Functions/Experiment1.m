% 对撞实验 0度 60度 90度 120度 180度
% 指标：完成任务的平均时间 速度变化率 平均最近距离 危险行为次数 碰撞次数
% Test Method:
% clc
% clear
% [UAV1,UAV2] = Experiment1(90,20,1);
function [UAV1,UAV2] = Experiment1(angle,UAVnumber,ReTry)

switch angle
    case 0
        Keywords1 = 'line0_1';
        Keywords2 = 'line0_2';
    case 60
        Keywords1 = 'line60_1';
        Keywords2 = 'line60_2';
    case 90
        Keywords1 = 'line90_1';
        Keywords2 = 'line90_2';
    case 120
        Keywords1 = 'line120_1';
        Keywords2 = 'line120_2';
    case 180
        Keywords1 = 'line180_1';
        Keywords2 = 'line180_2';
end
for i=1:UAVnumber
    [guideline,startpoint,~] = GetEnvironment(Keywords1);
    UAV1(i)=UAV(startpoint(1),startpoint(2));
    UAV1(i).guideline = guideline;
end
for i=1:UAVnumber
    [guideline,startpoint,~] = GetEnvironment(Keywords2);
    UAV2(i)=UAV(startpoint(1),startpoint(2));
    UAV2(i).guideline = guideline;
end
T = 0;
Stop1 = zeros(1,size(UAV1,2)); % UAV1机群的状态记录表
Stop2 = zeros(1,size(UAV2,2)); % UAV2机群的状态记录表
while (~all(Stop1))||(~all(Stop2))
    T = T + 1;

    % 更新机群的姿态
    for i = 1:size(UAV1,2)
        if size(UAV1(i).guideline,2)>0
            UAV1(i)=UAV1(i).update(UAV1,UAV2);
        else
            Stop1(i) = 1;
        end
    end
    for i = 1:size(UAV2,2)
        if size(UAV2(i).guideline,2)>0
            UAV2(i)=UAV2(i).update(UAV2,UAV1);
        else
            Stop2(i) = 1;
        end
    end

    % 记录机群的状态
    for i = 1:size(UAV1,2)
        if ~Stop1(i)
            UAV1(i)=UAV1(i).count(UAV1,UAV2,T);
        end
    end
    for i = 1:size(UAV2,2)
        if ~Stop2(i)
            UAV2(i)=UAV2(i).count(UAV2,UAV1,T);
        end
    end

    % 将UAV集群中完成任务的个体放置在远离机群的位置，防止对其他无人机产生干扰
    for i = 1:size(UAV1,2)
        if Stop1(i)
            UAV1(i).Pos = [0 0];
        end
    end
    for i = 1:size(UAV2,2)
        if Stop2(i)
            UAV2(i).Pos = [0 0];
        end
    end
end
save(['Experiment 1 Collision experiments/Experiment1 angle=',num2str(angle),' N=',num2str(UAVnumber),'×2 (',num2str(ReTry),').mat'])
end






