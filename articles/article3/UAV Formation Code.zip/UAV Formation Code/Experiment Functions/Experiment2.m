% 引导线跟随实验 直线 正弦线 梯形方波120度 
% 指标：完成任务的平均时间 速度变化率 平均最近距离 危险行为次数 碰撞次数
% Test Method:
% clc
% clear
% [UAVs] = Experiment2('line',20,1);
function [UAVs] = Experiment2(shape,UAVnumber,ReTry)

switch shape
    case 'line'
        Keywords = 'line';
    case 'trapezium'
        Keywords = 'trapezium';
    case 'sine'
        Keywords = 'sine';
end
for i=1:UAVnumber
    [guideline,startpoint,~] = GetEnvironment(Keywords);
    UAVs(i)=UAV(startpoint(1),startpoint(2));
    UAVs(i).guideline = guideline;
end

T = 0;
Stop = zeros(1,size(UAVs,2)); % 机群的状态记录表

while ~all(Stop)

    T = T + 1;
    % 更新机群的姿态
    for i = 1:size(UAVs,2)
        if size(UAVs(i).guideline,2)>0
            UAVs(i)=UAVs(i).update(UAVs,[]);
        else
            Stop(i) = 1;
        end
    end

    % 记录机群的状态
    for i = 1:size(UAVs,2)
        if ~Stop(i)
            UAVs(i)=UAVs(i).count(UAVs,[],T);
        end
    end

    % 将UAV集群中完成任务的个体放置在远离机群的位置，防止对其他无人机产生干扰
    for i = 1:size(UAVs,2)
        if Stop(i)
            UAVs(i).Pos = [0 0];
        end
    end
end
save(['Experiment 2 Turn experiments/Experiment2 shape=',shape,' N=',num2str(UAVnumber),' (',num2str(ReTry),').mat']);
end