% 无人机数量压力测试 
% 指标：速度变化率 平均最近距离 危险行为次数 碰撞次数
% ChangeN 必须为偶数
% Eindex = 1: 环境：圆形场同向定速追逐
% Eindex = 2: 环境：圆形场同向变速追逐
% Eindex = 3: 环境：圆形场异向定速追逐 
% Eindex = 4: 环境：圆形场异向变速追逐 
% Test Method:
% clc
% clear
% [UAV1,UAV2] = Experiment6(1000,50,2,4,1);
function [UAV1,UAV2] = Experiment6(MaxT,EveryT,ChangeN,Eindex,ReTry)

switch Eindex
    case 1
        twodirection   = 0;
        velocitychange = 0;
    case 2
        twodirection   = 0;
        velocitychange = 1;
    case 3
        twodirection   = 1;
        velocitychange = 0;
    case 4
        twodirection   = 1;
        velocitychange = 1;
end

UAVnumber = ChangeN;
for i=1:ChangeN/2
    [guideline,startpoint,~] = GetEnvironment2([],1);
    UAV1(i)=UAV(startpoint(1),startpoint(2));
    UAV1(i).guideline = guideline;
end
for i=1:ChangeN/2
    [guideline,startpoint,~] = GetEnvironment2([],twodirection+1);
    UAV2(i)=UAV(startpoint(1),startpoint(2));
    UAV2(i).guideline = guideline;
end

T = 0;
Stop1 = zeros(1,size(UAV1,2)); % UAV1机群的状态记录表
Stop2 = zeros(1,size(UAV2,2)); % UAV2机群的状态记录表
while T<MaxT
    T = T + 1;
    if mod(T,EveryT)==0 && T~=MaxT
        for j = 1:ChangeN/2
            [guideline,startpoint,~] = GetEnvironment2([],1);
            UAV1(UAVnumber/2+1)=UAV(startpoint(1),startpoint(2));
            UAV1(UAVnumber/2+1).guideline = guideline;
        end
        for j = 1:ChangeN/2
            [guideline,startpoint,~] = GetEnvironment2([],twodirection+1);
            UAV2(UAVnumber/2+1)=UAV(startpoint(1),startpoint(2));
            UAV2(UAVnumber/2+1).guideline = guideline;
        end
        UAVnumber = UAVnumber + 2;
        Stop1 = [Stop1 zeros(1,ChangeN/2)];
        Stop2 = [Stop2 zeros(1,ChangeN/2)];

        % 变速
        if velocitychange
            for i = 1:size(UAV1,2)
                if ~Stop1(i)
                    UAV1(i).maxV = 0.7 + rand*0.3;
                    UAV1(i).maxF = 0.7 + rand*0.3;
                end
            end
            for i = 1:size(UAV2,2)
                if ~Stop2(i)
                    UAV2(i).maxV = 0.7 + rand*0.3;
                    UAV2(i).maxF = 0.7 + rand*0.3;
                end
            end
        end
    end

    % 更新机群的姿态
    for i = 1:size(UAV1,2)
        if size(UAV1(i).guideline,2)>0
            if twodirection
                UAV1(i)=UAV1(i).update(UAV1,UAV2);
            else
                UAV1(i)=UAV1(i).update([UAV1,UAV2],[]);
            end
        else
            Stop1(i) = 1;
        end
    end
    for i = 1:size(UAV2,2)
        if size(UAV2(i).guideline,2)>0
            if twodirection
                UAV2(i)=UAV2(i).update(UAV2,UAV1);
            else
                UAV2(i)=UAV2(i).update([UAV2,UAV1],[]);
            end
        else
            Stop2(i) = 1;
        end
    end

    % 记录机群的状态
    for i = 1:size(UAV1,2)
        if ~Stop1(i)
            if twodirection
                UAV1(i)=UAV1(i).count(UAV1,UAV2,T);
            else
                UAV1(i)=UAV1(i).count([UAV1,UAV2],[],T);
            end
        end
    end
    for i = 1:size(UAV2,2)
        if ~Stop2(i)
            if twodirection
                UAV2(i)=UAV2(i).count(UAV2,UAV1,T);
            else
                UAV2(i)=UAV2(i).count([UAV2,UAV1],[],T);
            end
        end
    end

    % 更新机群的引导线
    for i = 1:size(UAV1,2)
        if ~Stop1(i)
            [guideline,~,~] = GetEnvironment2(UAV1(i).Pos,1);
            UAV1(i).guideline = guideline;
        end
    end
    for i = 1:size(UAV2,2)
        if ~Stop2(i)
            [guideline,~,~] = GetEnvironment2(UAV2(i).Pos,twodirection+1);
            UAV2(i).guideline = guideline;
        end
    end

    % 将UAV集群中完成任务的个体放置在远离机群的位置，防止对其他无人机产生干扰
    for i = 1:size(UAV1,2)
        if Stop1(i)
            UAV1(i).Pos = [0 0];
        end
    end
    for i = 1:size(UAV2,2)
        if Stop2(i)
            UAV2(i).Pos = [0 0];
        end
    end
end
switch Eindex
    case 1
        save(['Experiment 6 UAV number pressure experiments/Experiment6 same direction without velocity change MaxN=',num2str(UAVnumber),' (',num2str(ReTry),').mat']);
    case 2
        save(['Experiment 6 UAV number pressure experiments/Experiment6 same direction with velocity change MaxN=',num2str(UAVnumber),' (',num2str(ReTry),').mat']);
    case 3
        save(['Experiment 6 UAV number pressure experiments/Experiment6 opposite direction without velocity change MaxN=',num2str(UAVnumber),' (',num2str(ReTry),').mat']);
    case 4
        save(['Experiment 6 UAV number pressure experiments/Experiment6 opposite direction with velocity change MaxN=',num2str(UAVnumber),' (',num2str(ReTry),').mat']);
end

end