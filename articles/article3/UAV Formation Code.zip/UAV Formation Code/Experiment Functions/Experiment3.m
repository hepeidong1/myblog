% 编队收敛时间 用方向的误差反应
% 环境：直线飞行
% Test Method:
% clc
% clear
% [UAVs] = Experiment3(20,1);
function [UAVs] = Experiment3(UAVnumber,ReTry)
Keywords = 'line';
for i=1:UAVnumber
    [guideline,startpoint,~] = GetEnvironment(Keywords);
    UAVs(i)=UAV(startpoint(1),startpoint(2));
    UAVs(i).guideline = guideline;
end

T = 0;
Stop = zeros(1,size(UAVs,2)); % UAV1机群的状态记录表

while ~all(Stop)

    T = T + 1;
    % 更新机群的姿态
    for i = 1:size(UAVs,2)
        if size(UAVs(i).guideline,2)>0
            UAVs(i)=UAVs(i).update(UAVs,[]);
        else
            Stop(i) = 1;
        end
    end

    % 记录机群的状态
    for i = 1:size(UAVs,2)
        if ~Stop(i)
            UAVs(i)=UAVs(i).count(UAVs,[],T);
        end
    end

    % 将UAV集群中完成任务的个体放置在远离机群的位置，防止对其他无人机产生干扰
    for i = 1:size(UAVs,2)
        if Stop(i)
            UAVs(i).Pos = [0 0];
        end
    end
end
save(['Experiment 3 Convergence time experiments/Experiment3 N=',num2str(UAVnumber),' (',num2str(ReTry),').mat']);
end