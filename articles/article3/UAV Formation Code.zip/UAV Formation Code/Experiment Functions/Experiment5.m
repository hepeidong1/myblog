% 队内无人机数量的添加与减少
% 环境：圆形场定速
% 指标：速度变化率 平均最近距离 危险行为次数 碰撞次数
% Test Method:
% clc
% clear
% [UAVs] = Experiment5(2000,50,2,1);
function [UAVs] = Experiment5(MaxT,EveryT,ChangeN,ReTry)
UAVnumber = ChangeN;
DeletedNumber = 0;
for i=1:UAVnumber
    [guideline,startpoint,~] = GetEnvironment2([],1);
    UAVs(i)=UAV(startpoint(1),startpoint(2));
    UAVs(i).guideline = guideline;
end

T = 0;
Stop = zeros(1,size(UAVs,2));
while T<=MaxT*0.6

    T = T + 1;
    if mod(T,EveryT)==0 && T~=MaxT
        for j = 1:ChangeN
            [guideline,startpoint,~] = GetEnvironment2([],1);
            UAVs(UAVnumber+1)=UAV(startpoint(1),startpoint(2));
            UAVs(UAVnumber+1).guideline = guideline;
            UAVnumber = UAVnumber + 1;
        end
        Stop = [Stop zeros(1,ChangeN)];
    end

    % 更新机群的姿态
    for i = 1:size(UAVs,2)
        if size(UAVs(i).guideline,2)>0
            UAVs(i)=UAVs(i).update(UAVs,[]);
        else
            Stop(i) = 1;
        end
    end

    % 记录机群的状态
    for i = 1:size(UAVs,2)
        if ~Stop(i)
            UAVs(i)=UAVs(i).count(UAVs,[],T);
        end
    end

    % 更新机群的引导线
    for i = 1:size(UAVs,2)
        if ~Stop(i)
            [guideline,~,~] = GetEnvironment2(UAVs(i).Pos,1);
            UAVs(i).guideline = guideline;
        end
    end

    % 将UAV集群中完成任务的个体放置在远离机群的位置，防止对其他无人机产生干扰
    for i = 1:size(UAVs,2)
        if Stop(i)
            UAVs(i).Pos = [0 0];
        end
    end
end
MaxN = UAVnumber;
while T<MaxT

    T = T + 1;
    if mod(T,EveryT)==0 && T~=MaxT
        for j = 1:ChangeN
            DeletedNumber = DeletedNumber + 1;
            UAVnumber = UAVnumber - 1;
        end
    end

    % 更新机群的姿态
    for i = DeletedNumber+1:size(UAVs,2)
        if size(UAVs(i).guideline,2)>0
            UAVs(i)=UAVs(i).update(UAVs,[]);
        end
    end

    % 记录机群的状态
    for i = DeletedNumber+1:size(UAVs,2)
        if ~Stop(i)
            UAVs(i)=UAVs(i).count(UAVs,[],T);
        end
    end

    % 更新机群的引导线
    for i = DeletedNumber+1:size(UAVs,2)
        if ~Stop(i)
            [guideline,~,~] = GetEnvironment2(UAVs(i).Pos,1);
            UAVs(i).guideline = guideline;
        end
    end

    % 将UAV集群中完成任务的个体放置在远离机群的位置，防止对其他无人机产生干扰
    for i = 1:DeletedNumber
        Stop(i) = 1;
        UAVs(i).Pos = [0 0];
    end
end
save(['Experiment 5 Quantitative change experiments/Experiment5 MaxN=',num2str(MaxN),' (',num2str(ReTry),').mat']);
end