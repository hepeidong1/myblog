% 该函数用于统计重复实验中大量无人机的平均性能指标
function [allAverageVelocityImpact,allAverageVelocityChange,allAverageMinDistance,allAverageRunTime,...
    allsumWarningTime,allsumCollisionTime,counter,TAverageVelocityImpact,TAverageVelocityChange,...
    TAverageMinDistance,TsumWarningTime,TsumCollisionTime] = StatisticsUAV(UAVs)

runtime = size(UAVs,2);
uavN = size(UAVs{1,1},2);

% 预分配内存
r = runtime;
n = uavN;
AverageVelocityImpact(r,n) = UAVs{1,r}(1,n).AverageVelocityImpact;
AverageVelocityChange(r,n) = UAVs{1,r}(1,n).AverageVelocityChange;
AverageMinDistance(r,n) = UAVs{1,r}(1,n).AverageMinDistance;
RunTime(r,n) = UAVs{1,r}(1,n).RunTime;
WarningTime(r,n) = UAVs{1,r}(1,n).WarningTime;
CollisionTime(r,n) = UAVs{1,r}(1,n).CollisionTime;
RunT(r*uavN+n-uavN) = UAVs{1,r}(1,n).RunTime;
VelocityImpact(r*uavN+n-uavN,:) = UAVs{1,r}(1,n).VelocityImpact;
VelocityChange(r*uavN+n-uavN,:) = UAVs{1,r}(1,n).VelocityChange;
MinDistance(r*uavN+n-uavN,:) = UAVs{1,r}(1,n).MinDistance;
WarningCounter(r*uavN+n-uavN,:) = UAVs{1,r}(1,n).WarningCounter;
CollisionCounter(r*uavN+n-uavN,:) = UAVs{1,r}(1,n).CollisionCounter;

for r = 1:runtime
    for n = 1:uavN
        AverageVelocityImpact(r,n) = UAVs{1,r}(1,n).AverageVelocityImpact;
        AverageVelocityChange(r,n) = UAVs{1,r}(1,n).AverageVelocityChange;
        AverageMinDistance(r,n) = UAVs{1,r}(1,n).AverageMinDistance;
        RunTime(r,n) = UAVs{1,r}(1,n).RunTime;
        WarningTime(r,n) = UAVs{1,r}(1,n).WarningTime;
        CollisionTime(r,n) = UAVs{1,r}(1,n).CollisionTime;

        RunT(r*uavN+n-uavN) = UAVs{1,r}(1,n).RunTime;
        VelocityImpact(r*uavN+n-uavN,RunT(r*uavN+n-uavN)) = 0;
        VelocityChange(r*uavN+n-uavN,RunT(r*uavN+n-uavN)) = 0;
        MinDistance(r*uavN+n-uavN,RunT(r*uavN+n-uavN)) = 0;
        WarningCounter(r*uavN+n-uavN,RunT(r*uavN+n-uavN)) = 0;
        CollisionCounter(r*uavN+n-uavN,RunT(r*uavN+n-uavN)) = 0;

        VelocityImpact(r*uavN+n-uavN,1:max(3000,RunT(r*uavN+n-uavN))) = UAVs{1,r}(1,n).VelocityImpact;
        VelocityChange(r*uavN+n-uavN,1:max(3000,RunT(r*uavN+n-uavN))) = UAVs{1,r}(1,n).VelocityChange;
        MinDistance(r*uavN+n-uavN,1:max(3000,RunT(r*uavN+n-uavN))) = UAVs{1,r}(1,n).MinDistance;
        WarningCounter(r*uavN+n-uavN,1:max(3000,RunT(r*uavN+n-uavN))) = UAVs{1,r}(1,n).WarningCounter;
        CollisionCounter(r*uavN+n-uavN,1:max(3000,RunT(r*uavN+n-uavN))) = UAVs{1,r}(1,n).CollisionCounter;
    end
end

% 修正
MinDistance = MinDistance.*(MinDistance<100) + (MinDistance>=100);

allAverageVelocityImpact = mean(mean(AverageVelocityImpact));
allAverageVelocityChange = mean(mean(AverageVelocityChange));
allAverageMinDistance = mean(mean(AverageMinDistance));
allAverageRunTime = mean(mean(RunTime));
allsumWarningTime = sum(sum(WarningTime));
allsumCollisionTime = sum(sum(CollisionTime));
clear AverageVelocityImpact AverageVelocityChange AverageMinDistance RunTime WarningTime CollisionTime

for i = 1:runtime*uavN
    counter(i,find(MinDistance(i,:)~=0,1):find(MinDistance(i,:)~=0,1)+RunT(i)-1) = 1;
end
VelocityImpact   = sum(VelocityImpact);
VelocityChange   = sum(VelocityChange);
MinDistance      = sum(MinDistance);
WarningCounter   = sum(WarningCounter);
CollisionCounter = sum(CollisionCounter);

counter = sum(counter);
TAverageVelocityImpact = VelocityImpact(1:size(counter,2))./counter;
TAverageVelocityChange = VelocityChange(1:size(counter,2))./counter;
TAverageMinDistance    = MinDistance(1:size(counter,2))./counter;
TsumWarningTime        = WarningCounter(1:size(counter,2))./counter;
TsumCollisionTime      = CollisionCounter(1:size(counter,2))./counter;
end