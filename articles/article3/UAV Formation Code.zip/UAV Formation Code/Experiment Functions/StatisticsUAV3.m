% 该函数用于统计重复实验中大量无人机的平均性能指标 
% 与StatisticsUAV函数不同，该函数有三个输入值，分别表示三个不同机群，但机群的作用相同，因此可以一起统计
function [allAverageVelocityImpact,allAverageVelocityChange,allAverageMinDistance,allAverageRunTime,...
    allsumWarningTime,allsumCollisionTime,counter,TAverageVelocityImpact,TAverageVelocityChange,...
    TAverageMinDistance,TsumWarningTime,TsumCollisionTime] = StatisticsUAV3(UAV1,UAV2,UAV3)

runtime = size(UAV1,2);
uavN = size(UAV1{1,1},2)+size(UAV2{1,1},2)+size(UAV3{1,1},2);
for i = 1:runtime
    UAV{1,i} = [UAV1{1,i} UAV2{1,i} UAV3{1,i}];
end

% 预分配内存
r = runtime;
n = uavN;
AverageVelocityImpact(r,n) = UAV{1,r}(1,n).AverageVelocityImpact;
AverageVelocityChange(r,n) = UAV{1,r}(1,n).AverageVelocityChange;
AverageMinDistance(r,n) = UAV{1,r}(1,n).AverageMinDistance;
RunTime(r,n) = UAV{1,r}(1,n).RunTime;
WarningTime(r,n) = UAV{1,r}(1,n).WarningTime;
CollisionTime(r,n) = UAV{1,r}(1,n).CollisionTime;
RunT(r*uavN+n-uavN) = UAV{1,r}(1,n).RunTime;
VelocityImpact(r*uavN+n-uavN,:) = UAV{1,r}(1,n).VelocityImpact;
VelocityChange(r*uavN+n-uavN,:) = UAV{1,r}(1,n).VelocityChange;
MinDistance(r*uavN+n-uavN,:) = UAV{1,r}(1,n).MinDistance;
WarningCounter(r*uavN+n-uavN,:) = UAV{1,r}(1,n).WarningCounter;
CollisionCounter(r*uavN+n-uavN,:) = UAV{1,r}(1,n).CollisionCounter;

for r = 1:runtime
    for n = 1:uavN
        AverageVelocityImpact(r,n) = UAV{1,r}(1,n).AverageVelocityImpact;
        AverageVelocityChange(r,n) = UAV{1,r}(1,n).AverageVelocityChange;
        AverageMinDistance(r,n) = UAV{1,r}(1,n).AverageMinDistance;
        RunTime(r,n) = UAV{1,r}(1,n).RunTime;
        WarningTime(r,n) = UAV{1,r}(1,n).WarningTime;
        CollisionTime(r,n) = UAV{1,r}(1,n).CollisionTime;

        RunT(r*uavN+n-uavN) = UAV{1,r}(1,n).RunTime;
        VelocityImpact(r*uavN+n-uavN,:) = UAV{1,r}(1,n).VelocityImpact;
        VelocityChange(r*uavN+n-uavN,:) = UAV{1,r}(1,n).VelocityChange;
        MinDistance(r*uavN+n-uavN,:) = UAV{1,r}(1,n).MinDistance;
        WarningCounter(r*uavN+n-uavN,:) = UAV{1,r}(1,n).WarningCounter;
        CollisionCounter(r*uavN+n-uavN,:) = UAV{1,r}(1,n).CollisionCounter;
    end
end

% 修正
MinDistance = MinDistance.*(MinDistance<100) + (MinDistance>=100);

allAverageVelocityImpact = mean(mean(AverageVelocityImpact));
allAverageVelocityChange = mean(mean(AverageVelocityChange));
allAverageMinDistance = mean(mean(AverageMinDistance));
allAverageRunTime = mean(mean(RunTime));
allsumWarningTime = sum(sum(WarningTime));
allsumCollisionTime = sum(sum(CollisionTime));
clear AverageVelocityImpact AverageVelocityChange AverageMinDistance RunTime WarningTime CollisionTime

for i = 1:runtime*uavN
    counter(i,find(MinDistance(i,:)~=0,1):find(MinDistance(i,:)~=0,1)+RunT(i)-1) = 1;
end
VelocityImpact   = sum(VelocityImpact);
VelocityChange   = sum(VelocityChange);
MinDistance      = sum(MinDistance);
WarningCounter   = sum(WarningCounter);
CollisionCounter = sum(CollisionCounter);

counter = sum(counter);
TAverageVelocityImpact = VelocityImpact(1:size(counter,2))./counter;
TAverageVelocityChange = VelocityChange(1:size(counter,2))./counter;
TAverageMinDistance    = MinDistance(1:size(counter,2))./counter;
TsumWarningTime        = WarningCounter(1:size(counter,2))./counter;
TsumCollisionTime      = CollisionCounter(1:size(counter,2))./counter;
end