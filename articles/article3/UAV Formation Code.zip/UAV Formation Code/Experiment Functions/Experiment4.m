% 队形分离与组合 自适应组队
% 环境：三线 -> 两线 -> 三线
% 指标：速度变化率 平均最近距离 危险行为次数 碰撞次数
% Test Method:
% clc
% clear
% [UAV1,UAV2,UAV3] = Experiment4(10,1);
function [UAV1,UAV2,UAV3] = Experiment4(UAVnumber,ReTry)

for i=1:UAVnumber
    [guideline,startpoint,~] = GetEnvironment('SC1_1');
    UAV1(i)=UAV(startpoint(1),startpoint(2));
    UAV1(i).guideline = guideline;
end
for i=1:UAVnumber
    [guideline,startpoint,~] = GetEnvironment('SC1_2');
    UAV2(i)=UAV(startpoint(1),startpoint(2));
    UAV2(i).guideline = guideline;
end
for i=1:UAVnumber
    [guideline,startpoint,~] = GetEnvironment('SC1_4');
    UAV3(i)=UAV(startpoint(1),startpoint(2));
    UAV3(i).guideline = guideline;
end

T = 0;
Stop1 = zeros(1,size(UAV1,2)); % UAV1机群的状态记录表
Stop2 = zeros(1,size(UAV2,2)); % UAV2机群的状态记录表
Stop3 = zeros(1,size(UAV3,2)); % UAV3机群的状态记录表
Change1 = Stop1; % 记录机群中个体是否完成队形分离与组合 0:未完成 1:完成第一次 2:完成第二次
Change2 = Stop2; % 记录机群中个体是否完成队形分离与组合 0:未完成 1:完成第一次 2:完成第二次
Change3 = Stop3; % 记录机群中个体是否完成队形分离与组合 0:未完成 1:完成第一次 2:完成第二次

while (~all(Stop1))||(~all(Stop2))||(~all(Stop3))
    T = T + 1;

    % 更新编队
    % 进入第一个边界 编队二分离到编队一三中
    for i = size(UAV2,2):-1:1
        if (Change2(i)>0)||(UAV2(i).guideline(1,1)<200)
            % 未进入第一区域或已经调整过
        elseif rand>0.5 % 进入第一编队
            Change2(i) = 1;
            guideline = GetEnvironment('SC1_2');
            UAV2(i).guideline = guideline;
            Stop1 = [Stop1 Stop2(i)];
            Stop2(i) = [];
            Change1 = [Change1 Change2(i)];
            Change2(i) = [];
            UAV1 = [UAV1 UAV2(i)];
            UAV2(i) = [];
        else % 进入第二编队
            Change2(i) = 1;
            guideline = GetEnvironment('SC1_3');
            UAV2(i).guideline = guideline;
            Stop3 = [Stop3 Stop2(i)];
            Stop2(i) = [];
            Change3 = [Change3 Change2(i)];
            Change2(i) = [];
            UAV3 = [UAV3 UAV2(i)];
            UAV2(i) = [];
        end
    end
    % 进入第二个边界 编队一三中的部分无人机分离组合为编队二
    for i = size(UAV1,2):-1:1
        if (Change1(i)==2)||(UAV1(i).guideline(1,1)<600)
            % 未进入第二区域或已调整过一次
        elseif rand<0.667 % 留在第一编队
            Change1(i) = 2;
            guideline = GetEnvironment('SC1_1');
            UAV1(i).guideline = guideline;
        else % 进入第二编队
            Change1(i) = 2;
            guideline = GetEnvironment('SC1_2');
            UAV1(i).guideline = guideline;
            Stop2 = [Stop2 Stop1(i)];
            Stop1(i) = [];
            Change2 = [Change2 Change1(i)];
            Change1(i) = [];
            UAV2 = [UAV2 UAV1(i)];
            UAV1(i) = [];
        end
    end
    for i = size(UAV3,2):-1:1
        if (Change3(i)==2)||(UAV3(i).guideline(1,1)<600)
            % 未进入第二区域或已调整过一次
        elseif rand<0.667 % 留在第三编队
            Change3(i) = 2;
            guideline = GetEnvironment('SC1_4');
            UAV3(i).guideline = guideline;
        else % 进入第二编队
            Change3(i) = 2;
            guideline = GetEnvironment('SC1_3');
            UAV3(i).guideline = guideline;
            Stop2 = [Stop2 Stop3(i)];
            Stop3(i) = [];
            Change2 = [Change2 Change3(i)];
            Change3(i) = [];
            UAV2 = [UAV2 UAV3(i)];
            UAV3(i) = [];
        end
    end

    % 更新机群的姿态
    for i = 1:size(UAV1,2)
        if size(UAV1(i).guideline,2)>0
            UAV1(i)=UAV1(i).update(UAV1,[UAV2 UAV3]);
        else
            Stop1(i) = 1;
        end
    end
    for i = 1:size(UAV2,2)
        if size(UAV2(i).guideline,2)>0
            UAV2(i)=UAV2(i).update(UAV2,[UAV1 UAV3]);
        else
            Stop2(i) = 1;
        end
    end
    for i = 1:size(UAV3,2)
        if size(UAV3(i).guideline,2)>0
            UAV3(i)=UAV3(i).update(UAV3,[UAV1 UAV2]);
        else
            Stop3(i) = 1;
        end
    end

    % 记录机群的状态
    for i = 1:size(UAV1,2)
        if ~Stop1(i)
            UAV1(i)=UAV1(i).count(UAV1,[UAV2 UAV3],T);
        end
    end
    for i = 1:size(UAV2,2)
        if ~Stop2(i)
            UAV2(i)=UAV2(i).count(UAV2,[UAV1 UAV3],T);
        end
    end
    for i = 1:size(UAV3,2)
        if ~Stop3(i)
            UAV3(i)=UAV3(i).count(UAV3,[UAV1 UAV2],T);
        end
    end

    % 将UAV集群中完成任务的个体放置在远离机群的位置，防止对其他无人机产生干扰
    for i = 1:size(UAV1,2)
        if Stop1(i)
            UAV1(i).Pos = [0 0];
        end
    end
    for i = 1:size(UAV2,2)
        if Stop2(i)
            UAV2(i).Pos = [0 0];
        end
    end
    for i = 1:size(UAV3,2)
        if Stop3(i)
            UAV3(i).Pos = [0 0];
        end
    end
end
save(['Experiment 4 Formation separation and combination experiment/Experiment4 N=',num2str(UAVnumber),'×3 (',num2str(ReTry),').mat']);
end






