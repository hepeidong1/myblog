% 视频生成程序
%% 1 对撞实验 0 60 90 120 180 度的碰撞实验
clc
clear
warning off
load('Experiment 1 Collision experiments/A Experiment1.mat','TAverageMinDistance')
angle = [0 60 90 120 180];
UAVnumber = [5 10 20 30 40 50];
runtime = 30;
for i = 1:5
    for j = 1:6
        parfor retry = 1:runtime
            maxT = size(TAverageMinDistance{i,j},2);
            videoExperiment1(angle(i),UAVnumber(j),retry,maxT);
        end
        for retry = 1:runtime
            name = ngvExperiment1(angle(i),UAVnumber(j),retry);
            load(['H:/mp4/Video' name '.mat'],'frame');
            video = VideoWriter(['H:/mp4/Video' name],'MPEG-4');
            video.FrameRate = 60;
            open(video)
            writeVideo(video,frame);
            close(video)
        end
    end
end

%% 2 引导线跟随实验 直线 梯形方波 正弦线120度
clc
clear
warning off
load('Experiment 2 Turn experiments/A Experiment2.mat','TAverageMinDistance')
shape = {'line','trapezium','sine'};
UAVnumber = [10 20 30 40 50 60 70 80 90 100];
runtime = 30;
for i = 1:3
    for j = 1:10
        parfor retry = 1:runtime
            maxT = size(TAverageMinDistance{i,j},2);
            videoExperiment2(shape{i},UAVnumber(j),retry,maxT);
        end
        for retry = 1:runtime
            name = ngvExperiment2(shape{i},UAVnumber(j),retry);
            load(['H:/mp4/Video' name '.mat'],'frame');
            video = VideoWriter(['H:/mp4/Video' name],'MPEG-4');
            video.FrameRate = 60;
            open(video)
            writeVideo(video,frame(2:end));
            close(video)
        end
    end
end


%% 3 编队收敛时间
clc
clear
warning off
load('Experiment 3 Convergence time experiments/A Experiment3.mat','TAverageMinDistance')
UAVnumber = [10 20 30 40 50 60 70 80 90 100];
runtime = 30;
i = 1;
for j = 1:10
    parfor retry = 1:runtime
        maxT = size(TAverageMinDistance{i,j},2);
        videoExperiment3(UAVnumber(j),retry,maxT);
    end
    for retry = 1:runtime
        name = ngvExperiment3(UAVnumber(j),retry);
        load(['H:/mp4/Video' name '.mat'],'frame');
        video = VideoWriter(['H:/mp4/Video' name],'MPEG-4');
        video.FrameRate = 60;
        open(video)
        writeVideo(video,frame(2:end));
        close(video)
    end
end

%% 4 队形分离与组合 自适应组队
clc
clear
warning off
load('Experiment 4 Formation separation and combination experiment/A Experiment4.mat','TAverageMinDistance')
UAVnumber = [10 20 30 40 50];
runtime = 30;
i = 1;
for j = 1:5
    parfor retry = 1:runtime
        maxT = size(TAverageMinDistance{i,j},2);
        videoExperiment4(UAVnumber(j),retry,maxT);
    end
    for retry = 1:runtime
        name = ngvExperiment4(UAVnumber(j),retry);
        load(['H:/mp4/Video' name '.mat'],'frame');
        video = VideoWriter(['H:/mp4/Video' name],'MPEG-4');
        video.FrameRate = 60;
        open(video)
        writeVideo(video,frame(2:end));
        close(video)
    end
end

%% 5 队内无人机数量的添加与减少
clc
clear
warning off
load('Experiment 5 Quantitative change experiments/A Experiment5.mat','TAverageMinDistance')
i = 1;
j = 1;
runtime = 30;
parfor retry = 1:runtime
    maxT = size(TAverageMinDistance{i,j},2);
    videoExperiment5(3000,30,4,retry,maxT);
end
for retry = 1:runtime
    name = ngvExperiment5(3000,30,4,retry);
    load(['H:/mp4/Video' name '.mat'],'frame');
    video = VideoWriter(['H:/mp4/Video' name],'MPEG-4');
    video.FrameRate = 60;
    open(video)
    writeVideo(video,frame(2:2:3000));
    close(video)
end


%% 6 无人机数量压力测试
% Eindex = 1: 环境：圆形场同向定速追逐
% Eindex = 2: 环境：圆形场同向变速追逐
clc
clear
warning off
load('Experiment 6 UAV number pressure experiments/A Experiment6.mat','TAverageMinDistance')
i = 1;
runtime = 30;
for j = 1:2
    parfor retry = 1:runtime
        maxT = size(TAverageMinDistance{i,j},2);
        videoExperiment6(3000,30,4,j,retry,maxT);
    end
    for retry = 1:runtime
        name = ngvExperiment6(3000,30,4,j,retry);
        load(['H:/mp4/Video' name '.mat'],'frame');
        video = VideoWriter(['H:/mp4/Video' name],'MPEG-4');
        video.FrameRate = 60;
        open(video)
        writeVideo(video,frame(2:2:3000));
        close(video)
    end
end

%% 7 信号干扰
% Eindex = 1: 环境：圆形场同向定速追逐
% Eindex = 2: 环境：圆形场同向变速追逐
clc
clear
warning off
load('Experiment 7 Signal interference experiments/A Experiment7.mat','TAverageMinDistance')
SI = [0 0.05 0.1 0.15];
runtime = 30;
for i = 1:4
    for j = 1:2
        parfor retry = 1:runtime
            maxT = size(TAverageMinDistance{i,j},2);
            videoExperiment7(3000,30,4,j,SI(i),retry,maxT);
        end
        for retry = 1:runtime
            name = ngvExperiment7(3000,30,4,j,SI(i),retry);
            load(['H:/mp4/Video' name '.mat'],'frame');
            video = VideoWriter(['H:/mp4/Video' name],'MPEG-4');
            video.FrameRate = 60;
            open(video)
            writeVideo(video,frame(2:2:3000));
            close(video)
        end
    end
end

%% 8 消融实验
% Eindex = 1: 环境：圆形场同向定速追逐
% Eindex = 2: 环境：圆形场同向变速追逐
% method = OR: 本文提出的原始方法
% method = LF: 去除渐进线性分离力
% method = EA: 去除逃逸方法策略
% method = CA: 去除两个编队微调层
clc
clear
warning off
load('Experiment 8 Ablation experiments/A Experiment8.mat','TAverageMinDistance')
method = {'OR','LF','EA','CA'};
runtime = 30;
for i = 1:4
    for j = 1:2
        parfor retry = 1:runtime
            maxT = size(TAverageMinDistance{i,j},2);
            videoExperiment8(3000,30,4,j,method{i},retry,maxT);
        end
        for retry = 1:runtime
            name = ngvExperiment8(3000,30,4,j,method{i},retry);
            load(['H:/mp4/Video' name '.mat'],'frame');
            video = VideoWriter(['H:/mp4/Video' name],'MPEG-4');
            video.FrameRate = 60;
            open(video)
            writeVideo(video,frame(2:2:3000));
            close(video)
        end
    end
end