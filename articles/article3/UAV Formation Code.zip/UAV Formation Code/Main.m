%% 1 对撞实验 0 60 90 120 180 度的碰撞实验
clc
clear
angle = [0 60 90 120 180];
UAVnumber = [5 10 20 30 40 50];
runtime = 30;
for i = 1:5
    for j = 1:6
        parfor retry = 1:runtime
            [uav1{retry},uav2{retry}] = Experiment1(angle(i),UAVnumber(j),retry);
        end
        UAV1{i,j} = uav1;
        UAV2{i,j} = uav2;
        [allAverageVelocityImpact(i,j),allAverageVelocityChange(i,j),allAverageMinDistance(i,j),allAverageRunTime(i,j),...
            allsumWarningTime(i,j),allsumCollisionTime(i,j),counter{i,j},TAverageVelocityImpact{i,j},TAverageVelocityChange{i,j},...
            TAverageMinDistance{i,j},TsumWarningTime{i,j},TsumCollisionTime{i,j}] = StatisticsUAV2(uav1,uav2);
    end
end
save('Experiment 1 Collision experiments/A Experiment1.mat')

%% 2 引导线跟随实验 直线 梯形方波 正弦线120度 
clc
clear
shape = {'line','trapezium','sine'};
UAVnumber = [10 20 30 40 50 60 70 80 90 100];
runtime = 30;
for i = 1:3
    for j = 1:10
        parfor retry = 1:runtime
            [UAVs{retry}] = Experiment2(shape{i},UAVnumber(j),retry)
        end
        UAV{i,j} = UAVs;
        [allAverageVelocityImpact(i,j),allAverageVelocityChange(i,j),allAverageMinDistance(i,j),allAverageRunTime(i,j),...
            allsumWarningTime(i,j),allsumCollisionTime(i,j),counter{i,j},TAverageVelocityImpact{i,j},TAverageVelocityChange{i,j},...
            TAverageMinDistance{i,j},TsumWarningTime{i,j},TsumCollisionTime{i,j}] = StatisticsUAV(UAVs);
    end
end
save('Experiment 2 Turn experiments/A Experiment2.mat')

%% 3 编队收敛时间
clc
clear
UAVnumber = [10 20 30 40 50 60 70 80 90 100];
runtime = 30;
i = 1;
for j = 1:10
    parfor retry = 1:runtime
        [UAVs{retry}] = Experiment3(UAVnumber(j),retry)
    end
    UAV{j} = UAVs;
    [allAverageVelocityImpact(i,j),allAverageVelocityChange(i,j),allAverageMinDistance(i,j),allAverageRunTime(i,j),...
        allsumWarningTime(i,j),allsumCollisionTime(i,j),counter{i,j},TAverageVelocityImpact{i,j},TAverageVelocityChange{i,j},...
        TAverageMinDistance{i,j},TsumWarningTime{i,j},TsumCollisionTime{i,j}] = StatisticsUAV(UAVs);
end
save('Experiment 3 Convergence time experiments/A Experiment3.mat')

%% 4 队形分离与组合 自适应组队
clc
clear
UAVnumber = [10 20 30 40 50];
runtime = 30;
i = 1;
for j = 1:5
    parfor retry = 1:runtime
        [uav1{retry},uav2{retry},uav3{retry}] = Experiment4(UAVnumber(j),retry)
    end
    UAV1{j} = uav1;
    UAV2{j} = uav2;
    UAV3{j} = uav3;
    [allAverageVelocityImpact(i,j),allAverageVelocityChange(i,j),allAverageMinDistance(i,j),allAverageRunTime(i,j),...
        allsumWarningTime(i,j),allsumCollisionTime(i,j),counter{i,j},TAverageVelocityImpact{i,j},TAverageVelocityChange{i,j},...
        TAverageMinDistance{i,j},TsumWarningTime{i,j},TsumCollisionTime{i,j}] = StatisticsUAV3(uav1,uav2,uav3);
end
save('Experiment 4 Formation separation and combination experiment/A Experiment4.mat')

%% 5 队内无人机数量的添加与减少
clc
clear
i = 1;
j = 1;
runtime = 30;
parfor retry = 1:runtime
    [UAVs{retry}] = Experiment5(3000,30,4,retry)
end
[allAverageVelocityImpact(i,j),allAverageVelocityChange(i,j),allAverageMinDistance(i,j),allAverageRunTime(i,j),...
    allsumWarningTime(i,j),allsumCollisionTime(i,j),counter{i,j},TAverageVelocityImpact{i,j},TAverageVelocityChange{i,j},...
    TAverageMinDistance{i,j},TsumWarningTime{i,j},TsumCollisionTime{i,j}] = StatisticsUAV(UAVs);
save('Experiment 5 Quantitative change experiments/A Experiment5.mat')

%% 6 无人机数量压力测试 
% Eindex = 1: 环境：圆形场同向定速追逐
% Eindex = 2: 环境：圆形场同向变速追逐
clc
clear
i = 1;
runtime = 30;
for j = 1:2
    parfor retry = 1:runtime
        [uav1{retry},uav2{retry}] = Experiment6(3000,30,4,j,retry)
    end
        UAV1{i,j} = uav1;
        UAV2{i,j} = uav2;
        [allAverageVelocityImpact(i,j),allAverageVelocityChange(i,j),allAverageMinDistance(i,j),allAverageRunTime(i,j),...
            allsumWarningTime(i,j),allsumCollisionTime(i,j),counter{i,j},TAverageVelocityImpact{i,j},TAverageVelocityChange{i,j},...
            TAverageMinDistance{i,j},TsumWarningTime{i,j},TsumCollisionTime{i,j}] = StatisticsUAV2(uav1,uav2);
end
save('Experiment 6 UAV number pressure experiments/A Experiment6.mat')

%% 7 信号干扰
% Eindex = 1: 环境：圆形场同向定速追逐
% Eindex = 2: 环境：圆形场同向变速追逐
clc
clear
SI = [0 0.05 0.1 0.15];
runtime = 30;
for i = 1:4
    for j = 1:2
        parfor retry = 1:runtime
            [uav1{retry},uav2{retry}] = Experiment7(3000,30,4,j,SI(i),retry)
        end
        UAV1{i,j} = uav1;
        UAV2{i,j} = uav2;
        [allAverageVelocityImpact(i,j),allAverageVelocityChange(i,j),allAverageMinDistance(i,j),allAverageRunTime(i,j),...
            allsumWarningTime(i,j),allsumCollisionTime(i,j),counter{i,j},TAverageVelocityImpact{i,j},TAverageVelocityChange{i,j},...
            TAverageMinDistance{i,j},TsumWarningTime{i,j},TsumCollisionTime{i,j}] = StatisticsUAV2(uav1,uav2);
    end
end
save('Experiment 7 Signal interference experiments/A Experiment7.mat')

%% 8 消融实验
% Eindex = 1: 环境：圆形场同向定速追逐
% Eindex = 2: 环境：圆形场同向变速追逐
% method = OR: 本文提出的原始方法
% method = LF: 去除渐进线性分离力
% method = EA: 去除逃逸方法策略
% method = CA: 去除两个编队微调层
clc
clear
method = {'OR','LF','EA','CA'};
runtime = 30;
for i = 1:4
    for j = 1:2
        parfor retry = 1:runtime
            [uav1{retry},uav2{retry}] = Experiment8(3000,30,4,j,method{i},retry)
        end
        UAV1{i,j} = uav1;
        UAV2{i,j} = uav2;
        [allAverageVelocityImpact(i,j),allAverageVelocityChange(i,j),allAverageMinDistance(i,j),allAverageRunTime(i,j),...
            allsumWarningTime(i,j),allsumCollisionTime(i,j),counter{i,j},TAverageVelocityImpact{i,j},TAverageVelocityChange{i,j},...
            TAverageMinDistance{i,j},TsumWarningTime{i,j},TsumCollisionTime{i,j}] = StatisticsUAV2(uav1,uav2);
    end
end
save('Experiment 8 Ablation experiments/A Experiment8.mat')

