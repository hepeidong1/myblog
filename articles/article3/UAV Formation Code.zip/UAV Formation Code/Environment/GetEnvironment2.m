function [guideline,startpoint,viewposition] = GetEnvironment2(position,direction)
warning('off') 
switch direction
    case 1
        [SX,SY] = cylinder(1,30);
        x = 150+100*SX(1,:);
        y = 150+100*SY(1,:);
        guideline = [x;y];
        guideline = guideline(:,end:-1:1);
        d = pdist([position; guideline']);
        d = d(1:size(guideline,2));
        [~,minindex] = min(d);
        guideline = [guideline(:,minindex+1:end) guideline(:,1:minindex)];
        guideline(:,0.5*size(guideline,2):end) = [];
        startpoint = [-50+50*rand,100+100*rand];
        viewposition = [0 300 0 300];
    case 2
        [SX,SY] = cylinder(1,30);
        x = 150+100*SX(1,:);
        y = 150+100*SY(1,:);
        guideline = [x;y];
        d = pdist([position; guideline']);
        d = d(1:size(guideline,2));
        [~,minindex] = min(d); % 找出最近的引导点
        guideline = [guideline(:,minindex+1:end) guideline(:,1:minindex)];
        guideline(:,0.5*size(guideline,2):end) = [];
        startpoint = [-50+50*rand,100+100*rand];
        viewposition = [0 300 0 300];
end
end