function [guideline,startpoint,viewposition] = GetEnvironment(shape)

switch shape
    case 'line0_1'
        x = 100:50:500;
        y = 300*ones(1,9);
        guideline = [x;y];
        startpoint = [100*rand,250+100*rand];
        viewposition = [50 550 200 400];
    case 'line0_2'
        x = 100:50:500;
        y = 300*ones(1,9);
        guideline = [x;y];
        startpoint = [100*rand,250+100*rand];
        viewposition = [50 550 200 400];
    case 'line60_1'
        x = 50:35:615.6;
        y = linspace(450,50,17);
        guideline = [x;y];
        startpoint = [100*rand,400+100*rand];
        viewposition = [0 650 0 500];
    case 'line60_2'
        x = 50:35:615.6;
        y = linspace(50,450,17);
        guideline = [x;y];
        startpoint = [100*rand,100*rand];
        viewposition = [0 650 0 500];
    case 'line90_1'
        x = 100:50:500;
        y = 300*ones(1,9);
        guideline = [x;y];
        startpoint = [100*rand,250+100*rand];
        viewposition = [50 550 50 550];
    case 'line90_2'
        y = 100:50:500;
        x = 300*ones(1,9);
        guideline = [x;y];
        startpoint = [250+100*rand,100*rand];
        viewposition = [50 550 50 550];
    case 'line120_1'
        x = 50:35:615.6;
        y = linspace(50,450,17);
        guideline = [x;y];
        startpoint = [100*rand,100*rand];
        viewposition = [0 650 0 500];
    case 'line120_2'
        x = 615.6:-35:50;
        y = linspace(50,450,17);
        guideline = [x;y];
        startpoint = [560+100*rand,100*rand];
        viewposition = [0 650 0 500];
    case 'line180_1'
        x = 100:50:500;
        y = 200*ones(1,9);
        guideline = [x;y];
        startpoint = [100*rand,150+100*rand];
        viewposition = [50 550 0 400];
    case 'line180_2'
        x = 100:50:500;
        y = 200*ones(1,9);
        guideline = [x;y];
        guideline = guideline(:,size(guideline,2):-1:1);
        startpoint = [500+100*rand,150+100*rand];
        viewposition = [50 550 0 400];
    case 'line'
        x = 100:50:1400;
        y = 200*ones(1,27);
        guideline = [x;y];
        startpoint = [100*rand,150+100*rand];
        viewposition = [0 1450 0 400];
    case 'trapezium'
        x = [0:25:200 200:50:400 400:25:600 600:50:800 800:25:1000];
        y = [linspace(200,500,9) 500*ones(1,5) linspace(500,200,9) 200*ones(1,5) linspace(200,500,9)];
        guideline = [x;y];
        startpoint = [-50+100*rand,150+100*rand];
        viewposition = [0 1000 150 550];
    case 'sine'
        x = 0:50:800;
        y = 600+400*sin(pi*x./400);
        guideline = [x+25;y];
        startpoint = [-50+100*rand,550+100*rand];
        viewposition = [0 850 150 1050];
    case 'SC1_1'
        x = [0:50:200 200:25:400 400:50:600 600:25:800 800:50:1000];
        y = [500*ones(1,5) linspace(500,400,9) 400*ones(1,5) linspace(400,500,9) 500*ones(1,5)];
        guideline = [x+25;y];
        startpoint = [-50+100*rand,450+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC1_2'
        x = [0:50:200 200:25:400 400:50:600 600:25:800 800:50:1000];
        y = [300*ones(1,5) linspace(300,400,9) 400*ones(1,5) linspace(400,300,9) 300*ones(1,5)];
        guideline = [x+25;y];
        startpoint = [-50+100*rand,250+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC1_3'
        x = [0:50:200 200:25:400 400:50:600 600:25:800 800:50:1000];
        y = [300*ones(1,5) linspace(300,200,9) 200*ones(1,5) linspace(200,300,9) 300*ones(1,5)];
        guideline = [x+25;y];
        startpoint = [-50+100*rand,250+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC1_4'
        x = [0:50:200 200:25:400 400:50:600 600:25:800 800:50:1000];
        y = [100*ones(1,5) linspace(100,200,9) 200*ones(1,5) linspace(200,100,9) 100*ones(1,5)];
        guideline = [x+25;y];
        startpoint = [-50+100*rand,50+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC2_1'
        x = [0:50:200 200:25:400 400:50:600 600:25:800 800:50:1000];
        y = [300*ones(1,5) linspace(300,500,9) 500*ones(1,5) linspace(500,300,9) 300*ones(1,5)];
        guideline = [x+25;y];
        startpoint = [-50+100*rand,250+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC2_2'
        x = [0:50:200 200:25:400 400:50:600 600:25:800 800:50:1000];
        y = [300*ones(1,5) linspace(300,300,9) 300*ones(1,5) linspace(300,300,9) 300*ones(1,5)];
        guideline = [x+25;y];
        startpoint = [-50+100*rand,250+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC2_3'
        x = [0:50:200 200:25:400 400:50:600 600:25:800 800:50:1000];
        y = [300*ones(1,5) linspace(300,100,9) 100*ones(1,5) linspace(100,300,9) 300*ones(1,5)];
        guideline = [x+25;y];
        startpoint = [-50+100*rand,250+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC3_1'
        x = 0:50:1000;
        y = 400*ones(1,21);
        guideline = [x+25;y];
        startpoint = [-50+100*rand,350+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC3_2'
        x = 0:50:1000;
        y = 300*ones(1,21);
        guideline = [x+25;y];
        startpoint = [-50+100*rand,250+100*rand];
        viewposition = [0 1100 0 600];
    case 'SC3_3'
        x = 0:50:1000;
        y = 200*ones(1,21);
        guideline = [x+25;y];
        startpoint = [-50+100*rand,150+100*rand];
        viewposition = [0 1100 0 600];
end
end