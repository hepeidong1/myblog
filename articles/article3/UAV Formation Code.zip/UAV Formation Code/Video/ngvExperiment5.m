function [name,guideline,viewposition] = ngvExperiment5(~,~,~,ReTry)
MaxN = 244;
[~,~,viewposition] = GetEnvironment2([],1);
[SX,SY] = cylinder(1,30);
x = 150+100*SX(1,:);
y = 150+100*SY(1,:);
guideline = [x;y];
name = ['Experiment 5 Quantitative change experiments/Experiment5 MaxN=',num2str(MaxN),' (',num2str(ReTry),')'];
end