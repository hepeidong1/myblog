function frame = GenerateFrame3(retry,maxT,name,guideline,viewposition,uav1,uav2,uav3)

    fi = figure(retry+100);
    set(fi,'Visible','off')
    hold on
    axis(viewposition);
    textinmap = text(viewposition(1)+10,viewposition(3)+10,'Time = ');

    xl = viewposition(2) - viewposition(1);
    yl = viewposition(4) - viewposition(3);
    if (xl/800)>(yl/600)
        set(fi,'Position',[0 0 800 ceil(800*yl/xl)])
    else
        set(fi,'Position',[0 0 ceil(600*xl/yl) 600])
    end

    if size(guideline,1)==2
        plot(guideline(1,:),guideline(2,:),'k')
    elseif size(guideline,1)==4
        plot(guideline(1,:),guideline(2,:),'r')
        plot(guideline(3,:),guideline(4,:),'b')
    else
        plot(guideline(1,:),guideline(2,:),'r')
        plot(guideline(3,:),guideline(4,:),'g')
        plot(guideline(5,:),guideline(6,:),'b')
        plot(guideline(7,:),guideline(8,:),'m')
    end

    NowPosition1 = zeros(size(uav1,2),2);
    NowPosition2 = zeros(size(uav2,2),2);
    NowPosition3 = zeros(size(uav3,2),2);
    for t = 1:maxT
        if t == 2
            frame(maxT) = frame(1);
        end
        PastPosition1 = NowPosition1;
        for i=1:size(uav1,2)
            Ts = find(uav1(1,i).MinDistance~=0,1);
            Te = find(uav1(1,i).MinDistance~=0,1)+uav1(1,i).RunTime-1;
            if t<Ts
            elseif t>Te
                NowPosition1(i,:) = [-10;-10];
            else
                NowPosition1(i,:) = uav1(1,i).PastPosition(t,:);
            end
        end
        o{1} = plotUAVswarm(PastPosition1,NowPosition1,'r');

        PastPosition2 = NowPosition2;
        for i=1:size(uav2,2)
            Ts = find(uav2(1,i).MinDistance~=0,1);
            Te = find(uav2(1,i).MinDistance~=0,1)+uav2(1,i).RunTime-1;
            if t<Ts
            elseif t>Te
                NowPosition2(i,:) = [-10;-10];
            else
                NowPosition2(i,:) = uav2(1,i).PastPosition(t,:);
            end
        end
        o{2} = plotUAVswarm(PastPosition2,NowPosition2,'g');

        PastPosition3 = NowPosition3;
        for i=1:size(uav3,2)
            Ts = find(uav3(1,i).MinDistance~=0,1);
            Te = find(uav3(1,i).MinDistance~=0,1)+uav3(1,i).RunTime-1;
            if t<Ts
            elseif t>Te
                NowPosition3(i,:) = [-10;-10];
            else
                NowPosition3(i,:) = uav3(1,i).PastPosition(t,:);
            end
        end
        o{3} = plotUAVswarm(PastPosition3,NowPosition3,'b');

        [hour, minute, second] = s2hms(t/10);
        if second<10
            set(textinmap,'String',['Time = 00:0' num2str(minute) ':0' num2str(second)])
        else
            set(textinmap,'String',['Time = 00:0' num2str(minute) ':' num2str(second)])
        end
        pause(0.0001);
        frame(t) = getframe(fi);
        delete(o{1});
        delete(o{2});
        delete(o{3});
    end
    close(fi)
end