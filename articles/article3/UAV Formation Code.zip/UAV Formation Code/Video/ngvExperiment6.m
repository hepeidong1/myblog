function [name,guideline,viewposition] = ngvExperiment6(~,~,~,Eindex,ReTry)
[SX,SY] = cylinder(1,30);
x = 150+100*SX(1,:);
y = 150+100*SY(1,:);
guideline = [x;y];
[~,~,viewposition] = GetEnvironment2([],1);
UAVnumber = 202;

switch Eindex
    case 1
        name = ['Experiment 6 UAV number pressure experiments/Experiment6 same direction without velocity change MaxN=',num2str(UAVnumber),' (',num2str(ReTry),')'];
    case 2
        name = ['Experiment 6 UAV number pressure experiments/Experiment6 same direction with velocity change MaxN=',num2str(UAVnumber),' (',num2str(ReTry),')'];
end

end