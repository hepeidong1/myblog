function [name,guideline,viewposition] = ngvExperiment2(shape,UAVnumber,ReTry)

switch shape
    case 'line'
        Keywords = 'line';
    case 'trapezium'
        Keywords = 'trapezium';
    case 'sine'
        Keywords = 'sine';
end
[guideline,~,viewposition] = GetEnvironment(Keywords);
name = ['Experiment 2 Turn experiments/Experiment2 shape=',shape,' N=',num2str(UAVnumber),' (',num2str(ReTry),')'];
end