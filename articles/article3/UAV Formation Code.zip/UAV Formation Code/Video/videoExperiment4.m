function frame = videoExperiment4(UAVnumber,ReTry,maxT)
[guideline1,~,~] = GetEnvironment('SC1_1');
[guideline2,~,~] = GetEnvironment('SC1_2');
[guideline3,~,~] = GetEnvironment('SC1_3');
[guideline4,~,viewposition] = GetEnvironment('SC1_4');
name = ['Experiment 4 Formation separation and combination experiment/Experiment4 N=',num2str(UAVnumber),'×3 (',num2str(ReTry),')'];
guideline = [guideline1;guideline2;guideline3;guideline4];
load([name '.mat'],'UAV1','UAV2','UAV3')
frame = GenerateFrame3(ReTry,maxT,name,guideline,viewposition,UAV1,UAV2,UAV3);
save(['H:/mp4/Video' name '.mat'],'frame')
end