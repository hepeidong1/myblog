function [name,guideline,viewposition] = ngvExperiment1(angle,UAVnumber,ReTry)

switch angle
    case 0
        Keywords1 = 'line0_1';
        Keywords2 = 'line0_2';
    case 60
        Keywords1 = 'line60_1';
        Keywords2 = 'line60_2';
    case 90
        Keywords1 = 'line90_1';
        Keywords2 = 'line90_2';
    case 120
        Keywords1 = 'line120_1';
        Keywords2 = 'line120_2';
    case 180
        Keywords1 = 'line180_1';
        Keywords2 = 'line180_2';
end

    [guideline1,~,~] = GetEnvironment(Keywords1);
    [guideline2,~,viewposition] = GetEnvironment(Keywords2);

name = ['Experiment 1 Collision experiments/Experiment1 angle=',num2str(angle),' N=',num2str(UAVnumber),'×2 (',num2str(ReTry),')'];
guideline = [guideline1;guideline2];
end