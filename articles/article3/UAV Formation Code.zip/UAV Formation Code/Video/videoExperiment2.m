function frame = videoExperiment2(shape,UAVnumber,ReTry,maxT)

switch shape
    case 'line'
        Keywords = 'line';
    case 'trapezium'
        Keywords = 'trapezium';
    case 'sine'
        Keywords = 'sine';
end
[guideline,~,viewposition] = GetEnvironment(Keywords);
name = ['Experiment 2 Turn experiments/Experiment2 shape=',shape,' N=',num2str(UAVnumber),' (',num2str(ReTry),')'];

load([name '.mat'],'UAVs')
frame = GenerateFrame1(ReTry,maxT,name,guideline,viewposition,UAVs);
save(['H:/mp4/Video' name '.mat'],'frame')
end