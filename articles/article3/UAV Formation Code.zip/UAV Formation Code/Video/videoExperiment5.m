function frame = videoExperiment5(~,~,~,ReTry,maxT)
MaxN = 244;
[~,~,viewposition] = GetEnvironment2([],1);
[SX,SY] = cylinder(1,30);
x = 150+100*SX(1,:);
y = 150+100*SY(1,:);
guideline = [x;y];
name = ['Experiment 5 Quantitative change experiments/Experiment5 MaxN=',num2str(MaxN),' (',num2str(ReTry),')'];

load([name '.mat'],'UAVs')
frame = GenerateFrame1(ReTry,maxT,name,guideline,viewposition,UAVs);
save(['H:/mp4/Video' name '.mat'],'frame')
end