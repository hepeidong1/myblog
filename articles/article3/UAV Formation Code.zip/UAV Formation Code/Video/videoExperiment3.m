function frame = videoExperiment3(UAVnumber,ReTry,maxT)
Keywords = 'line';
[guideline,~,viewposition] = GetEnvironment(Keywords);
name = ['Experiment 3 Convergence time experiments/Experiment3 N=',num2str(UAVnumber),' (',num2str(ReTry),')'];
load([name '.mat'],'UAVs')
frame = GenerateFrame1(ReTry,maxT,name,guideline,viewposition,UAVs);
save(['H:/mp4/Video' name '.mat'],'frame')
end