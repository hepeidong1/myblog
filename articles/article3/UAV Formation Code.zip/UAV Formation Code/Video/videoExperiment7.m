function frame = videoExperiment7(~,~,~,Eindex,SI,ReTry,maxT)

[SX,SY] = cylinder(1,30);
x = 150+100*SX(1,:);
y = 150+100*SY(1,:);
guideline = [x;y];
[~,~,viewposition] = GetEnvironment2([],1);
UAVnumber = 202;

switch Eindex
    case 1
        name = ['Experiment 7 Signal interference experiments/Experiment7 same direction without velocity change N=',num2str(UAVnumber),' SI=',num2str(SI*100),'% (',num2str(ReTry),')'];
    case 2
        name = ['Experiment 7 Signal interference experiments/Experiment7 same direction with velocity change N=',num2str(UAVnumber),' SI=',num2str(SI*100),'% (',num2str(ReTry),')'];
end
load([name '.mat'],'UAV1','UAV2')
frame = GenerateFrame2(ReTry,maxT,name,guideline,viewposition,UAV1,UAV2);
save(['H:/mp4/Video' name '.mat'],'frame')
end