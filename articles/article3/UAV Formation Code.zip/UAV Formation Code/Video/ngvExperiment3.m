function [name,guideline,viewposition] = ngvExperiment3(UAVnumber,ReTry)
Keywords = 'line';
[guideline,~,viewposition] = GetEnvironment(Keywords);
name = ['Experiment 3 Convergence time experiments/Experiment3 N=',num2str(UAVnumber),' (',num2str(ReTry),')'];
end