function colorList=TheColor(type,num)
% type : type of colorbar
% num  : number of colors
% =========================================================================
% 感知一致： 1-6
% 单方向纯色渐变：7-25
% 较复杂渐变： 25-91
% 双方向渐变(两边深色中间浅色)： 92-125  
% 循环渐变(两侧颜色可以对接在一起)： 126-144
% 混杂渐变，用于山地、光谱等图绘制：145-176
% 离散colormap: 177-200
if nargin<2
    num=256;
end
if nargin<1
    type='';
end

TheColo=load('TheColor_Data.mat');
CList_Data=[TheColo.slandarerCM(:).Colors];

if isnumeric(type)
    Cmap=CList_Data{type};
else
    Cpos=strcmpi(type,TheColo.fullNames);
    Cmap=CList_Data{Cpos};
end

Ci=1:256;Cq=linspace(1,256,num);
colorList=[interp1(Ci,Cmap(:,1),Cq,'linear')',...
           interp1(Ci,Cmap(:,2),Cq,'linear')',...
           interp1(Ci,Cmap(:,3),Cq,'linear')'];
end