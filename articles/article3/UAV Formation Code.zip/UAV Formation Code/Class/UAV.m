classdef UAV

    properties
        Pos
        Vel
        Acc
        R
        maxF
        maxV
        Factor
        RAmodel
        TargetArea
        guideline
        
        pastV

        RunTime
        WarningTime
        CollisionTime
        VelocityImpact
        AverageVelocityImpact
        VelocityChange
        AverageVelocityChange
        MinDistance
        AverageMinDistance
        WarningCounter
        CollisionCounter
        PastPosition

    end

    methods
        function obj = UAV(Posx,Posy) % 构造函数
            % 模型数据
            obj.Acc = [0 0];
            obj.Vel = [rand*1e-5 rand*1e-5];
            obj.Pos = [Posx,Posy];
            obj.R = 1;
            obj.maxV = 0.7 + rand*0.3;
            obj.maxF = 0.7 + rand*0.3;
            obj.Factor = [1.2 0.1 0.1 1];
            obj.RAmodel = [3 50 75 90];
            obj.TargetArea = 50; % 引导距离
            obj.guideline = [];

            % 临时记录的信息
            obj.pastV = obj.Vel;

            % 记录用于分析的信息
            obj.RunTime = 0;
            obj.WarningTime = 0;
            obj.CollisionTime = 0;
            obj.VelocityImpact = zeros(1,3000);
            obj.AverageVelocityImpact = 0;
            obj.VelocityChange = zeros(1,3000);
            obj.AverageVelocityChange = 0;
            obj.MinDistance = zeros(1,3000);
            obj.AverageMinDistance = 0;
            obj.WarningCounter = zeros(1,3000);
            obj.CollisionCounter = zeros(1,3000);
            obj.PastPosition = -1*ones(3000,2);
        end

        function obj = count(obj,UAVs,otherUAVs,T) % 速度更新
            % 运行次数
            obj.RunTime = obj.RunTime + 1;

            % 对于速度的影响
            obj.VelocityImpact(T) = 1 - abs(norm(obj.Vel))/obj.maxV;
            if abs(obj.VelocityImpact(T)) < 1e-10
                obj.VelocityImpact(T) = 0;
            end
            obj.AverageVelocityImpact = sum(obj.VelocityImpact)/obj.RunTime;

            % 速度变化
            obj.VelocityChange(T) = abs(norm(obj.pastV - obj.Vel))/obj.maxF;
            obj.AverageVelocityChange = sum(obj.VelocityChange)/obj.RunTime;

            % 最近距离
            [~,obj.MinDistance(T)] = Collision(obj,[UAVs otherUAVs]);
            obj.AverageMinDistance = sum(obj.MinDistance)/obj.RunTime;

            % 危险警告
            if obj.MinDistance(T) < obj.RAmodel(1)
                obj.WarningTime = obj.WarningTime + 1;
                obj.WarningCounter(T) = 1;
            else
                obj.WarningCounter(T) = 0;
            end

            % 碰撞次数
            if obj.MinDistance(T) < obj.R
                obj.CollisionTime = obj.CollisionTime + 1;
                obj.CollisionCounter(T) = 1;
            else
                obj.CollisionCounter(T) = 0;
            end

            % 历史位置
            obj.PastPosition(T,:) = obj.Pos;

            % 修正 由于初始位置是随机生成的，因此不记录前10次运行的碰撞与警告结果
            if obj.RunTime==10
                obj.WarningTime = 0;
                obj.WarningCounter(T-9:T) = zeros(1,10);
                obj.CollisionTime = 0;
                obj.CollisionCounter(T-9:T) = zeros(1,10);
            end
        end

        function obj = update(obj,UAVs,otherUAVs) % 速度更新

            % 记录状态
            obj.pastV = obj.Vel;

            % 更新引导线矩阵
            positions = obj.guideline;
            if ~isempty(positions)
                d = pdist([obj.Pos; positions']);
                d = d(1:size(positions,2));
                [~,minindex] = min(d); % 找出最近的引导点
                if d(minindex) < obj.TargetArea
                    obj.guideline(:,1:minindex)=[];
                end
            end

            % 更新受力
            Fsep = obj.Cal_Fsep([UAVs otherUAVs]);
            Fcoh = obj.Cal_Fcoh(UAVs);
            Fali = obj.Cal_Fali(UAVs);
            Ffol = obj.Cal_Ffol();

            % 赋予影响因子
            Fsep = Fsep * obj.Factor(1); % 分离
            Fcoh = Fcoh * obj.Factor(2); % 凝聚
            Fali = Fali * obj.Factor(3); % 对齐
            Ffol = Ffol * obj.Factor(4); % 引导

            tempobj = obj;
            % 更新加速度
            tempobj.Acc = tempobj.Acc+1/sum(tempobj.Factor)*(Fsep+Fcoh+Fali+Ffol);

            % 限制速度
            tempobj.Vel = tempobj.Vel + tempobj.Acc;
            if norm(tempobj.Vel)>tempobj.maxV
                tempobj.Vel = tempobj.Vel./norm(tempobj.Vel).*tempobj.maxV;
            end
            tempobj.Pos = tempobj.Pos + tempobj.Vel;

            [tempCollision,tempd] = Collision(tempobj,[UAVs otherUAVs]);
            bestobj = tempobj;
            bestd = tempd;
            
            if tempCollision % 碰撞 避障 不保证避障成功 尝试20次
                for i = 1:20
                    if tempCollision
                        [x2,y2] = rotate(tempobj.Acc(1),tempobj.Acc(2),pi/10);
                        tempobj.Acc = [x2,y2];
                        % 限制速度
                        tempobj.Vel = obj.Vel + tempobj.Acc;
                        if norm(tempobj.Vel)>tempobj.maxV
                            tempobj.Vel = tempobj.Vel./norm(tempobj.Vel).*tempobj.maxV;
                        end
                        tempobj.Pos = obj.Pos + tempobj.Vel;

                        [tempCollision,tempd] = Collision(tempobj,[UAVs otherUAVs]);
                        if norm(tempd)>norm(bestd)
                            bestobj = tempobj;
                            bestd = tempd;
                        end
                    else
                        break
                    end
                end
                obj = bestobj;
            else
                % 更新加速度
                obj.Acc = obj.Acc+1/sum(obj.Factor)*(Fsep+Fcoh+Fali+Ffol);
                % 限制速度
                obj.Vel = obj.Vel + obj.Acc;
                if norm(obj.Vel)>obj.maxV
                    obj.Vel = obj.Vel./norm(obj.Vel).*obj.maxV;
                end
                obj.Pos = obj.Pos + obj.Vel;
            end
            obj.Acc = [0 0];
            

        end

        function [o,mindistance] = Collision(obj, UAVs) % 碰撞检测
            positions = zeros(2,length(UAVs));
            for i=1:1:length(UAVs)
                positions(:,i) = UAVs(i).Pos;
            end
            d = pdist([obj.Pos; positions']);
            d = d(1:length(UAVs));
            d = sort(d);
            mindistance = d(2);
            if mindistance < obj.RAmodel(1)
                o = 1;
            else
                o = 0;
            end
        end

        function force = Cal_Fsep(obj, UAVs) % 分离
            desired_separation = obj.RAmodel(2);
            force = [0,0];
            count = 0;
            positions = zeros(2,length(UAVs));
            for i=1:1:length(UAVs)
                positions(:,i) = UAVs(i).Pos;
            end
            d = pdist([obj.Pos; positions']);
            d = d(1:length(UAVs));

            for i=1:1:length(UAVs)
                if d(i) > 0 && d(i) <  desired_separation
                    difference = obj.Pos - UAVs(i).Pos;
                    difference = difference./norm(difference);
                    difference = difference./d(i);
                    force = force + difference;
                    count = count+1;
                end
            end

            if count > 0
                force = force./count;
            end

            if norm(force) > 0
                force = force./norm(force).*obj.maxV;
                force = force - obj.Vel;
                force = force./norm(force).*obj.maxF;
            end

            d= sort(d);
            mindistance = d(2);
            force = force*((1-mindistance/desired_separation));
        end

        function force = Cal_Fali(obj, UAVs) % 对齐
            sum = [0 0];
            count = 0;
            force = [0 0]; % 速度对齐
            positions = zeros(2,length(UAVs));
            for i=1:1:length(UAVs)
                positions(:,i) = UAVs(i).Pos;
            end
            d = pdist([obj.Pos; positions']);
            d = d(1:length(UAVs));

            for i=1:1:length(UAVs)
                if d(i)>obj.RAmodel(2) && d(i) < obj.RAmodel(3)
                    sum=sum+UAVs(i).Vel;
                    count=count+1;
                end
            end

            if count > 0
                sum=sum./count;
                sum=sum./norm(sum).*obj.maxV;
                force=sum-obj.Vel;
                force=force./norm(force).*obj.maxF;
            end
        end

        function force = Cal_Fcoh(obj, UAVs) % 凝聚 
            sum = [0 0];
            count = 0;
            force = [0 0];

            positions = zeros(2,length(UAVs));
            for i=1:1:length(UAVs)
                positions(:,i) = UAVs(i).Pos;
            end
            d = pdist([obj.Pos; positions']);
            d = d(1:length(UAVs));

            for i=1:1:length(UAVs)
                if d(i)>0 && d(i) < obj.RAmodel(4)
                    sum=sum+UAVs(i).Pos;
                    count=count+1;
                end
            end

            if count > 0
                sum=sum./count;
                desired = sum - obj.Pos;
                desired = desired./norm(desired)*obj.maxV;

                steer = desired-obj.Vel;
                force = steer./norm(steer).*obj.maxF;
            end
        end

        function force = Cal_Ffol(obj)   % 引导
            force = [0 0];
            positions = obj.guideline;
            if ~isempty(positions) % 无引导线直接跳出
                d = pdist([obj.Pos; positions']);
                d = d(1:size(positions,2));
                [~,minindex] = min(d); % 找出最近的引导点
                goalpoint = positions(:,minindex)';
                force = goalpoint - obj.Pos;

                if norm(force) > 0
                    force = force./norm(force).*obj.maxV;
                    force = force - obj.Vel;
                    force = force./norm(force).*obj.maxF;
                end
            end
        end

    end
end

function [x2,y2] = rotate(x1,y1,alpha)
    x2 = x1*cos(alpha) - y1*sin(alpha);
    y2 = x1*sin(alpha) + y1*cos(alpha);
end
