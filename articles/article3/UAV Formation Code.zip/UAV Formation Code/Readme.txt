**Distributed large-scale joint non-uniform UAV formation path planning system based on global optimal path guidance**

Gang Hu a, b*, Peidong He a, Kang Chen c, Guo Wei d
a *Department of Applied Mathematics, Xi**’**an University of Technology, Xi**’**an 710054, PR China*
b *School of Computer Science and Engineering,, Xi’an University of Technology, Xi’an 710048, PR China*
c Unmanned System Research Institute, Northwestern Polytechnical University, Xi’an 710072, PR China
d *University of North Carolina at Pembroke, Pembroke, NC 28372, USA*

Document description:

**File: Main**
**Implementation of the experiments in the paper**
**First run this file please!**

Folder: Class
These are some class functions that mainly record the various UAV models and their associated functions.

Folder: Environment
Inside are the various experimental environments mentioned in the article, and different environments are invoked by entering various parameters

Folder: Experiment Functions
It corresponds to the various experiments in the text and provides three functions for counting the relevant metrics

Folder: TheColor
Various colour schemes are provided, which can be used when generating images, or the system's default colour scheme can be used.
Download from{Zhaoxu Liu / slandarer (2024). 200 colormap (https://www.mathworks.com/matlabcentral/fileexchange/120088-200-colormap), MATLAB Central File Exchange. 检索时间: 2024/12/3.)}

Folder: Video
For video generation

File: GenerateVideo
For video generation

