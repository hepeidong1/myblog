function temp = plotsolution(solution,maxV,startpoint)

endr = maxV*solution(1);
endzeta = solution(2);
endphi = solution(3);
endpoint = startpoint + [endr*cos(endzeta)*sin(endphi),endr*cos(endzeta)*cos(endphi),endr*sin(endzeta)];
x = (0:20)/20 .*(endpoint(1) - startpoint(1)) + startpoint(1);
y = (0:20)/20 .*(endpoint(2) - startpoint(2)) + startpoint(2);
z = (0:20)/20 .*(endpoint(3) - startpoint(3)) + startpoint(3);

[ballx, bally, ballz] = sphere();
r = 3;
x(22) = x(21);
y(22) = y(21);
z(22) = z(21);
hold on

for i = 1:21
    pause(0.03);
    temp1(i)=surf(r*ballx+x(i),r*bally+y(i),r*ballz+z(i),'FaceColor','b','EdgeColor','none','FaceAlpha',0.2);
    temp2(i)=plot3([x(i),x(i+1)],[y(i),y(i+1)],[z(i),z(i+1)],'Color','k','LineStyle','-',LineWidth = 2);
end
delete(temp1);
delete(temp2);
temp = plot3(x,y,z,'Color','k','LineStyle','-',LineWidth = 2);
end

