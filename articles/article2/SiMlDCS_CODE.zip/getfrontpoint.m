function [thirdpoint] = getfrontpoint(solution,startpoint,maxV)
    endr = maxV*solution(1);
    thirdr = solution(5)*endr;
    thirdzeta = solution(6);
    thirdphi = solution(7);
    thirdpoint = startpoint + [thirdr*cos(thirdzeta)*sin(thirdphi),thirdr*cos(thirdzeta)*cos(thirdphi),thirdr*sin(thirdzeta)];
end

