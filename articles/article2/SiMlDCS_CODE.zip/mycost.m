function C = mycost(solution,robotstart,robotgoal,startpoint,generateline,linelogic,Map,Elements,axisParameter,maxV,id)

punishment = 5000;
safeH = 20;
robotR = Elements.Robot.R(id);
safedistance2line = Elements.Robot.R(id);

endr = maxV*solution(1);
endzeta = solution(2);
endphi = solution(3);
endpoint = startpoint + [endr*cos(endzeta)*sin(endphi),endr*cos(endzeta)*cos(endphi),endr*sin(endzeta)];

x = (0:20)/20 .*(endpoint(1) - startpoint(1))/norm(startpoint-endpoint) * maxV + startpoint(1);
y = (0:20)/20 .*(endpoint(2) - startpoint(2))/norm(startpoint-endpoint) * maxV + startpoint(2);
z = (0:20)/20 .*(endpoint(3) - startpoint(3))/norm(startpoint-endpoint) * maxV + startpoint(3);
all21point = [x;y;z];
clear x y z

% 1 
tempweight = ((startpoint(1)-robotgoal(1))^2+(startpoint(2)-robotgoal(2))^2)...
    /((robotstart(1)-robotgoal(1))^2+(robotstart(2)-robotgoal(2))^2);
k = 1+3*sqrt(tempweight);
C1 = sqrt((endpoint(1)-startpoint(1))^2+(endpoint(2)-startpoint(2))^2+(endpoint(3)-startpoint(3))^2) + sqrt(k^2*(endpoint(1)-robotgoal(1))^2+k^2*(endpoint(2)-robotgoal(2))^2+(endpoint(3)-robotgoal(3))^2);
clear k tempweight

% 2 
staticN = Elements.Static.N;
C2 = 0;
for i = 1:staticN
    warningDistance = robotR;
    distance2samplepoint = sqrt(sum((all21point(1:2,:)' - [Elements.Static.Position.x(i),Elements.Static.Position.y(i)]).^2,2));
    for j = 1:21
        if distance2samplepoint(j) < Elements.Static.R(i) +  robotR
            C2 = C2 + 1/distance2samplepoint(j)*punishment;
        elseif distance2samplepoint(j) < Elements.Static.R(i) +  robotR +  warningDistance
            C2 = C2 + (distance2samplepoint(j))^2*punishment;
        end
    end
end

% 3 
C3 = 0;
samplingpointN = size(all21point,2);
for i = 1:samplingpointN
    x = min(max(ceil(all21point(1,i)),1),axisParameter);
    y = min(max(ceil(all21point(2,i)),1),axisParameter);
    Hinmap = Map.Z(x,y);
    Hinline = all21point(3,i);
    DetaH = Hinline - Hinmap;
    if DetaH > safeH
        C3;
    elseif DetaH > 0
        C3 = C3 + (safeH-DetaH)*punishment;
    else 
        C3 = C3 + 100*(abs(DetaH)+safeH)*punishment;
    end
end

% 4 
C4 = 0;
samplingpointN = size(all21point,2);
for i = 1:samplingpointN
    C4 = C4 + abs(all21point(1,i)) * (all21point(1,i) < 0);
    C4 = C4 + abs(axisParameter - all21point(1,i)) * (all21point(1,i) > axisParameter);
    C4 = C4 + abs(all21point(2,i)) * (all21point(2,i) < 0);
    C4 = C4 + abs(axisParameter - all21point(2,i)) * (all21point(2,i) > axisParameter);
    C4 = C4 + abs(all21point(3,i)) * (all21point(3,i) < 0);
    C4 = C4 + abs(Map.H - all21point(3,i)) * (all21point(3,i) > Map.H);
end
C4 = C4*punishment;

% 5
C5 = 0;
uavN = size(generateline,1);
samplingpointN = size(all21point,2);
for i = 1:samplingpointN
    for j = 1:uavN
        if linelogic(j)==1
            distance2line = Distance2Threat(all21point(:,i)',generateline(j,1:3),generateline(j,4:6));
            if distance2line < safedistance2line + robotR + 3
                C5 = C5 + punishment^2;
            end
        else
            C5 = C5 + 0;
        end
    end
end


% 6
C6 = 0;


t= 0.5;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.1*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.02;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.2*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.02;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.3*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.02;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.4*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.02;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.5*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.02;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.6*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.002;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.7*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.002;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.8*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.002;
C6 = C6 + prepunishment1(startpoint,endpoint,t*0.9*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.002;
C6 = C6 + prepunishment1(startpoint,endpoint,t*1.0*maxV,Map,Elements,axisParameter,safeH,robotR,maxV)*punishment*0.002;


t = 0.5;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.1*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.2*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.3*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.4*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.5*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.6*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.7*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.8*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;
C6 = C6 + prepunishment2(startpoint,endpoint,t*0.9*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;
C6 = C6 + prepunishment2(startpoint,endpoint,t*1.0*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;


t = 0.5;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.1*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.2*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.3*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.4*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.5*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.02;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.6*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.7*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.8*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;
C6 = C6 + prepunishment3(startpoint,endpoint,t*0.9*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;
C6 = C6 + prepunishment3(startpoint,endpoint,t*1.0*maxV,Map,Elements,axisParameter,safeH,robotR)*punishment*0.002;

C = C1 + C2 + C3 + C4 + C5 +C6;
end


function x = Distance2Threat(p,a,b)
    Vector_ab = b - a;
    Vector_ap = p - a;
    ProjectionVector = ((Vector_ab*Vector_ap')/(Vector_ab*Vector_ab'))*(Vector_ab);
    ProjectionPoint = a + ProjectionVector;
    if ProjectionPoint(1)>min(a(1),b(1)) && ProjectionPoint(1)<max(a(1),b(1))
        x = sqrt((Vector_ap - ProjectionVector)*(Vector_ap - ProjectionVector)');
    else
        Distance(1) = norm(p-a);
        Distance(2) = norm(p-b);
        x = min(Distance);
    end
end


function C3 = prepunishment1(tp,ep,mV,Map,Elements,axisParameter,safeH,robotR,MaxV)
    x = (0:20)/20 .*(ep(1) - tp(1))/norm(tp-ep) * mV + ep(1);
    y = (0:20)/20 .*(ep(2) - tp(2))/norm(tp-ep) * mV + ep(2);
    z = (0:20)/20 .*(ep(3) - tp(3))/norm(tp-ep) * mV + ep(3);
    all21point = [x;y;z];
    clear x y z
    
    staticN = Elements.Static.N;
    C3 = 0;
    for i = 1:staticN
        warningDistance = robotR;
        distance2samplepoint = sqrt(sum((all21point(1:2,:)' - [Elements.Static.Position.x(i),Elements.Static.Position.y(i)]).^2,2));
        for j = 1:21
            if distance2samplepoint(j) < Elements.Static.R(i) +  robotR
                C3 = C3 + 1/distance2samplepoint(j);
            elseif distance2samplepoint(j) < Elements.Static.R(i) +  robotR +  warningDistance
                C3 = C3 + (distance2samplepoint(j))^2;
            end
        end
    end
end

function C5 = prepunishment2(tp,ep,mV,Map,Elements,axisParameter,safeH,robotR)
    x = (0:20)/20 .*(ep(1) - tp(1))/norm(tp-ep) * mV + ep(1);
    y = (0:20)/20 .*(ep(2) - tp(2))/norm(tp-ep) * mV + ep(2);
    z = (0:20)/20 .*(ep(3) - tp(3))/norm(tp-ep) * mV + ep(3);
    all21point = [x;y;z];
    clear x y z
    
    C5 = 0;
    samplingpointN = size(all21point,2);
    for i = 1:samplingpointN
        x = min(max(ceil(all21point(1,i)),1),axisParameter);
        y = min(max(ceil(all21point(2,i)),1),axisParameter);
        Hinmap = Map.Z(x,y);
        Hinline = all21point(3,i);
        DetaH = Hinline - Hinmap;
        if DetaH > safeH
            C5;
        elseif DetaH > 0
            C5 = C5 + (safeH-DetaH);
        else
            C5 = C5 + 100*(abs(DetaH)+safeH);
        end
    end
end

function C6 = prepunishment3(tp,ep,mV,Map,Elements,axisParameter,safeH,robotR)
    x = (0:20)/20 .*(ep(1) - tp(1))/norm(tp-ep) * mV + ep(1);
    y = (0:20)/20 .*(ep(2) - tp(2))/norm(tp-ep) * mV + ep(2);
    z = (0:20)/20 .*(ep(3) - tp(3))/norm(tp-ep) * mV + ep(3);
    all21point = [x;y;z];
    clear x y z
    C6 = 0;
    samplingpointN = size(all21point,2);
    for i = 1:samplingpointN
        C6 = C6 + abs(all21point(1,i)) * (all21point(1,i) < 0);
        C6 = C6 + abs(axisParameter - all21point(1,i)) * (all21point(1,i) > axisParameter);
        C6 = C6 + abs(all21point(2,i)) * (all21point(2,i) < 0);
        C6 = C6 + abs(axisParameter - all21point(2,i)) * (all21point(2,i) > axisParameter);
        C6 = C6 + abs(all21point(3,i)) * (all21point(3,i) < 0);
        C6 = C6 + abs(Map.H - all21point(3,i)) * (all21point(3,i) > Map.H);
    end
end
