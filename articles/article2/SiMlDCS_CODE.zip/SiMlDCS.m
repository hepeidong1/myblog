function [GBCost,GBPosition,Curve] = SiMlDCS(VarMin,VarMax,nVar,nPop,MaxIt,CostFunction) %,amoniter,bmoniter,cmoniter

VarMin = VarMin.*ones(1,nVar);
VarMax = VarMax.*ones(1,nVar);
GeneratedPosition = zeros(nPop,nVar);
FeasiblePosition = zeros(nPop,nVar);
eta_qKR = zeros(1,nPop);
newCost = zeros(nPop,1);

Curve = zeros(1,MaxIt);

% Golden ratio
golden_ratio = 2/(1 + sqrt(5));

% High-performing individuals
ngS = max(6,round(nPop * (golden_ratio/3)));

% Initialize the population
p = haltonset(nVar,'Skip',1e3,'Leap',1e2);
p = scramble(p,'RR2');
weight = p(1:nPop,:);
Position = VarMin + weight.* (VarMax - VarMin);

% for i = 1:nPop
%     Position(i,:) = VarMin + rand(1,nVar) .* (VarMax - VarMin);
% end

% Initialize fitness values
Cost = zeros(nPop,1);
for i = 1:nPop
    Cost(i,1) = CostFunction(Position(i,:));
end

% Generation
pc = 0.5; % probability constant 概率不变率

% Best solution
GBCost = min(Cost);

% Ranking-based self-improvement eq.8
phi_qKR = 0.25 + 0.55 * ((0 + ((1:nPop)/nPop)) .^ 0.5);

RP=zeros(2,nVar);

amonitercounter = zeros(nPop,MaxIt);
bmonitercounter = zeros(nPop,MaxIt);
cmonitercounter = zeros(nPop,MaxIt);
anum = 0;
bnum = 0;
cnum = 0;
for it = 1:MaxIt
    % Sort population by fitness values
    [Position, Cost, ~] = PopSort(Position,Cost);
    % Reset
    GBindex = 1;
    lamda_t = 0.1 + (0.518 * ((1-(it/MaxIt)^0.5)));
    D = squareform(pdist(Position, 'squaredeuclidean'));
    X_memory = Position;
    c = 0.95;

    anum = 0;
    bnum = 0;
    cnum = 0;

    for i = 1:nPop

        % quantized knowledge acquisition rate 量化知识获取率 eq.7
        eta_qKR(i) = (round(rand * phi_qKR(i)) + (rand <= phi_qKR(i)))/2;

        % eq.9 随机选取一个维度
        jrand = floor(nVar * rand + 1);
        GeneratedPosition(i,:) = Position(i,:);
        way = 0;
        if i > 0.95*nPop && rand < pc
            way = 1;
            anum = anum+1;
            ang=pi*rand;
            cv=randi(nPop);
            cv1=randi(nPop);
            Prb=0.2;    % The percentage of exploration other regions within the search space.
            if rand<rand
                a=(it/MaxIt)^(2*1/it);
            else
                a=(1-(it/MaxIt))^(2*(it/MaxIt));
            end

            for j=1:size(Position,2)
                %  Eq. (9)
                if ang~=pi/2
                    RP(1,j)=Position(i,j)+ (a*cos(ang)*(Position(cv,j)-Position(cv1,j)));
                else
                    RP(1,j)=Position(i,j)+ a*cos(ang)*(Position(cv,j)-Position(cv1,j))+a*RP(randi(2),j);
                end
                %  Eq. (10)
                if ang~=pi/2
                    RP(2,j)=Position(i,j)+ (a*cos(ang)*((VarMax(j)-VarMin(j))*rand+VarMin(j)))*(rand<Prb);
                else
                    RP(2,j)=Position(i,j)+ (a*cos(ang)*((VarMax(j)-VarMin(j))*rand+VarMin(j))+a*RP(randi(2),j))*(rand<Prb) ;
                end
            end
            if rand<rand
                for j=1:size(Position,2)
                    if  RP(2,j)>VarMax(j)
                        RP(2,j)=VarMin(j)+rand*(VarMax(j)-VarMin(j));
                    elseif  RP(2,j)<VarMin(j)
                        RP(2,j)=VarMin(j)+rand*(VarMax(j)-VarMin(j));
                    end
                end
            else
                RP(2,:) = min(max(RP(2,:),VarMin),VarMax);
            end

            if rand<rand
                for j=1:size(Position,2)
                    if  RP(1,j)>VarMax(j)
                        RP(1,j)=VarMin(j)+rand*(VarMax(j)-VarMin(j));
                    elseif  RP(1,j)<VarMin(j)
                        RP(1,j)=VarMin(j)+rand*(VarMax(j)-VarMin(j));
                    end
                end
            else
                RP(1,:) = min(max(RP(1,:),VarMin),VarMax);
            end
            cv=randi(nPop);
            % Eq. (16)
            if rand<rand % Eq. (13)
                for j=1:size(Position,2)
                    if rand>rand
                        GeneratedPosition(i,j)=Position(i,j)+rand*(Position(GBindex,j)-Position(i,j))+rand*(RP(1,j)-Position(cv,j));  %% Eq. (13)
                    end
                end
            else % Eq. (15)
                for j=1:size(Position,2)
                    if rand>rand
                        GeneratedPosition(i,j)=Position(i,j)+rand*(Position(GBindex,j)-Position(i,j))+rand*(RP(2,j)-Position(cv,j)); %% Eq. (15)
                    end
                end
            end

        elseif i < 3
            way = 2;
            bnum = bnum+1;
            while true, r1 = round(nPop * rand + 0.5); if r1 ~= i && r1 ~= GBindex, break, end, end
            for d = 1:nVar % eq.19
                if rand <= eta_qKR(i) || d == jrand
                    GeneratedPosition(i,d) = Position(r1,d) + LnF3(golden_ratio,0.05,1,1);
                end
            end
        else
            way = 3;
            cnum = cnum+1;

            while true, r1 = round(nPop * rand + 0.5); if r1 ~= i && r1 ~= GBindex, break, end, end
            while true, r2 = ngS + round((nPop - ngS) * rand + 0.5); if r2 ~= i && r2 ~= GBindex && r2 ~= r1, break, end, end

            Dimax = max(D(i,:));
            k = floor((1-it/MaxIt)*nPop)+1;  % Eq (9)
            [~, neighbors] = sort(D(i,:));
            % Attraction-Repulsion operator % Eq (6)
            delta_ni = zeros(1,nVar);
            for j=neighbors(1:k)
                I = 1 - (D(i,j)/Dimax);
                s = sign(Cost(j)-Cost(i));
                delta_ni = delta_ni + (X_memory(i,:)-X_memory(j,:))*I*s;
            end
            omega_it = rand;
            ni = delta_ni/nPop;
            for d = 1:nVar % eq.15
                if rand <= eta_qKR(i) || d == jrand
                    GeneratedPosition(i,d) = Position(GBindex,d) + ((Position(r2,d) - Position(i,d)) * lamda_t) + ((Position(r1,d) - Position(i,d)) * omega_it);
                else
                    GeneratedPosition(i,d) = Position(i,d) + 2.5*c*ni(d);
                end
            end

        end

        % Boundary boundary-handling mechanism eq.20
        OutBoundary = GeneratedPosition(i,:) < VarMin;
        GeneratedPosition(i,OutBoundary) = 0.5*(GeneratedPosition(i,OutBoundary) + VarMin(OutBoundary));
        OutBoundary = GeneratedPosition(i,:) > VarMax;
        GeneratedPosition(i,OutBoundary) = 0.5*(GeneratedPosition(i,OutBoundary) + VarMax(OutBoundary));

        % Boundary constant
        GeneratedPosition(i,:) = max(GeneratedPosition(i,:),VarMin);
        GeneratedPosition(i,:) = min(GeneratedPosition(i,:),VarMax);
        newCost(i,1) = CostFunction(GeneratedPosition(i,:));
        FeasiblePosition(i,:) = GeneratedPosition(i,:);

        if newCost(i,1) <= Cost(i,1) % (RA) Retrospective assessment
            Position(i,:) = FeasiblePosition(i,:); % Retrospect
            Cost(i,1) = newCost(i,1);
            if way == 1
                amonitercounter(i,it) = 1;
            elseif way==2
                bmonitercounter(i,it) = 1;
            else
                cmonitercounter(i,it) = 1;
            end
            if newCost(i,1) < GBCost
                GBCost = newCost(i,1); % eq.23
                GBindex = i;
            end
        end
    end

    if anum ~= 0
        amoniter(1,it) = sum(amonitercounter(:,it))/anum;
    elseif it==1
        amoniter(1,it) = 0.5;
    else
        amoniter(1,it) = amoniter(1,it-1);
    end
    bmoniter(1,it) = sum(bmonitercounter(:,it))/bnum;
    cmoniter(1,it) = sum(cmonitercounter(:,it))/cnum;

    Curve(it) = GBCost;
    GBPosition = Position(GBindex,:);
end
end

function [sorted_population, sorted_fitness, sorted_index] = PopSort(input_pop,input_fitness)
[sorted_fitness, sorted_index] = sort(input_fitness,1,'ascend');
sorted_population = input_pop(sorted_index,:);
end

function Y = LnF3(alpha, sigma, m, n)
Z = laplacernd(m, n);
Z = sign(rand(m,n)-0.5) .* Z;
U = rand(m, n);
R = sin(0.5*pi*alpha) .* tan(0.5*pi*(1-alpha*U)) - cos(0.5*pi*alpha);
Y = sigma * Z .* (R) .^ (1/alpha);
end

function x = laplacernd(m, n)
u1 = rand(m, n);
u2 = rand(m, n);
x = log(u1./u2);
end
