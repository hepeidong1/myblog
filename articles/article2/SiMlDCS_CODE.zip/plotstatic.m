function StaticThreat = plotstatic(Map,Elements)
    Hmax = Map.H;
    totalStatic = Elements.Static.N;
    hold on
    for i = 1:totalStatic
        StaticThreatX = Elements.Static.Position.x(i);
        StaticThreatY = Elements.Static.Position.y(i);
        StaticThreatR = Elements.Static.R(i);
    
        [SX,SY,SZ] = cylinder(1,150);
        sX = StaticThreatR*SX+StaticThreatX;
        sY = StaticThreatR*SY+StaticThreatY;
        sZ = Hmax*SZ;
        
        Alpha = 0.05;
        StaticThreat(3*i-2) = surf(sX,sY,sZ,'FaceColor','r','EdgeColor','none',FaceAlpha=Alpha);
        StaticThreat(3*i-1) = fill3(sX(1,:),sY(1,:),sZ(1,:),'r','EdgeColor','r',FaceAlpha=Alpha);
        StaticThreat(3*i) = fill3(sX(1,:),sY(1,:),sZ(2,:),'r','EdgeColor','r',FaceAlpha=Alpha);
    end
end