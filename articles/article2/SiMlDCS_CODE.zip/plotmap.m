function plotmap(Map,axisParameter)
    figureUnits = 'centimeters';
    figureWidth = 10;
    figureHeight = 10;

    set(gcf, 'Units', figureUnits, 'Position', [0 0 figureWidth figureHeight]);
    set(gca, 'FontName', 'Arial', 'FontSize', 11)
    % set(gcf,'Color',[1 1 1])% 背景颜色
    surf(Map.X,Map.Y,Map.Z','linewidth',0.5,'EdgeColor','none','FaceAlpha',0.9);
    axis([1 axisParameter 1 axisParameter 0 Map.H]);
    box on
    grid on
    light
    material dull
    colorbar
    axis tight
end

