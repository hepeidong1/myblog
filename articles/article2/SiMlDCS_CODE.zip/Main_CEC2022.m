close all
clc
clear

N=100;
T=100;
Dim = 10;
run = 30;

really = [3 4 6 8 9 18 20 22 23 24 26 27];
for Fuc = 1:12
    fobj=@(x) cec22_func(x',Fuc);
    [lb,ub,dim,~] = CEC2022(Fuc,Dim);
    parfor r = 1:run
        [~,~,f1(r,:)]=DCS(lb,ub,dim,N,T,fobj);
        [~,~,f2(r,:)]=SiMlDCS(lb,ub,dim,N,T,fobj);
    end
    cuve_f1 = mean(f1)-100*really(Fuc);
    cuve_f2 = mean(f2)-100*really(Fuc);
    XX = 1:T;
    figure
    semilogy(XX,cuve_f1,XX,cuve_f2,'LineWidth',3)
    xlabel('Iteration');
    ylabel('Error');
    legend({'DCS','SiMlDCS'});
    title(['F' num2str(Fuc) ]);
end