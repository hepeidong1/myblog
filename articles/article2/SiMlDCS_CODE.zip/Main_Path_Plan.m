% Notice:
% The code generates paths strictly using the PSCM process, with the blue
% objects in the image being temporary static obstacle areas and the white
% color being temporary static obstacle areas from previous time periods.

clc
clear
close all

% Creat Map
Map = CreateMap();
w=fspecial('gaussian',[6 7],5);
Map.Z = imfilter(Map.Z,w);

[axisParameter,Elements] = initialization(Map);

plotmap(Map,axisParameter)
plotstatic(Map,Elements)
pause(0.03);

maxV = 10;
stoplimit = 10;

MaxIt = 30; 
nPop = 30;
nVar = 3;
VarMin = [0.2 ,  -pi/2 , 0   ];
VarMax = [1   ,   pi/2 , 2*pi];

for robot_id = 1:Elements.Robot.N
    robotnow(robot_id,:)=[Elements.Robot.Start.x(robot_id),Elements.Robot.Start.y(robot_id),Elements.Robot.Start.z(robot_id)];
    Allgoal(robot_id,:)=[Elements.Robot.Goal.x(robot_id),Elements.Robot.Goal.y(robot_id),Elements.Robot.Goal.z(robot_id)];
    Allstart(robot_id,:)=[Elements.Robot.Start.x(robot_id),Elements.Robot.Start.y(robot_id),Elements.Robot.Start.z(robot_id)];
    robotdistance2goal(robot_id)=norm(robotnow(robot_id,:)-Allgoal(robot_id,:));
    robotstopflag(robot_id) = (norm(robotnow(robot_id,:)-Allgoal(robot_id,:)) < stoplimit);
end
it = 0;
while ~all(robotstopflag)
    generateline = zeros(Elements.Robot.N,6);
    linelogic = zeros(1,Elements.Robot.N);
    solution = zeros(Elements.Robot.N,3);
    it = it +1;


    for robot_id = 1:Elements.Robot.N

        CostFunction = @(sol) mycost(sol,Allstart(robot_id,:),Allgoal(robot_id,:),robotnow(robot_id,:),generateline,linelogic,Map,Elements,axisParameter,maxV,robot_id);

        if ~robotstopflag(robot_id)
            [~,solution(robot_id,:),~]=SiMlDCS(VarMin,VarMax,nVar,nPop,MaxIt,CostFunction);

            generateline(robot_id,:) = [robotnow(robot_id,:), robotnow(robot_id,:) + [maxV*solution(robot_id,1)*cos(solution(robot_id,2))*sin(solution(robot_id,3)),maxV*solution(robot_id,1)*cos(solution(robot_id,2))*cos(solution(robot_id,3)),maxV*solution(robot_id,1)*sin(solution(robot_id,2))]];
            linelogic(robot_id)=1;

            plotsolution(solution(robot_id,:),maxV,robotnow(robot_id,:));
            eval(['VV' int2str(robot_id) '=plotwarning(generateline(robot_id,:),''b'');'])

            [maxV*solution(robot_id,1)*cos(solution(robot_id,2))*sin(solution(robot_id,3)),maxV*solution(robot_id,1)*cos(solution(robot_id,2))*cos(solution(robot_id,3)),maxV*solution(robot_id,1)*sin(solution(robot_id,2))]
            robotnow(robot_id,:) = robotnow(robot_id,:) + [maxV*solution(robot_id,1)*cos(solution(robot_id,2))*sin(solution(robot_id,3)),maxV*solution(robot_id,1)*cos(solution(robot_id,2))*cos(solution(robot_id,3)),maxV*solution(robot_id,1)*sin(solution(robot_id,2))];
            robotdistance2goal(robot_id)=norm(robotnow(robot_id,:)-Allgoal(robot_id,:));
        end
    end
    for robot_id = 1:Elements.Robot.N
        eval(['delete(VV' int2str(robot_id) ');'])
        eval(['plotwarning(generateline(robot_id,:),''w'');'])
    end

    for robot_id = 1:Elements.Robot.N
        if ~robotstopflag(robot_id)
            robotstopflag(robot_id) = (norm(robotnow(robot_id,:)-Allgoal(robot_id,:)) < stoplimit);
        end
    end
end




















