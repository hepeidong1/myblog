function [axisParameter,Elements] = initialization(Map)
Z = Map.Z;
Hmax = Map.H;

totalRobot = 12; % number of robot
axisParameter = size(Z,1); % visualization scale (100 x 100)

robotRadius = ones(1, totalRobot); % radius of robot
robotStart.x = [5 5 5 5 5 5 95 95 95 95 95 95]*axisParameter/100; % start positions (x) of robots
robotStart.y = [5 25 40 60 75 95 5 25 40 60 75 95]*axisParameter/100; % start positions (y) of robots
robotStart.z = diag(Z(round(robotStart.x),round(robotStart.y)))'+0.2*(0.5+rand(1,totalRobot)).*(Hmax-diag(Z(round(robotStart.x),round(robotStart.y)))'); % start positions (z) of robots
robotGoal.x =  [95 95 95 95 95 95 5 5 5 5 5 5]*axisParameter/100; 
robotGoal.y =  [60 25 95 5 75 40 60 25 95 5 75 40]*axisParameter/100; 
robotGoal.z =  diag(Z(round(robotGoal.x),round(robotGoal.y)))'+0.2*(0.5+rand(1,totalRobot)).*(Hmax-diag(Z(round(robotGoal.x),round(robotGoal.y)))'); % goal positions (z) of robots

totalStatic = 13; % number of static obstacles
staticRadius = [3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3]*axisParameter/100; % radius of static obstacles
static.x = [20 20 80 80 35 35 65 65 50 50 50 80 20]*axisParameter/100; % positions (x) of static obstacles
static.y = [80 20 20 80 65 35 36 65 50 80 20 50 50]*axisParameter/100; % positions (y) of static obstacles

%% 整理数据
Elements.Robot.N            = totalRobot;
% Elements.Robot.N            = 2;
Elements.Robot.R            = robotRadius;
Elements.Robot.Start        = robotStart;
Elements.Robot.Goal         = robotGoal;

Elements.Static.N           = totalStatic;
% Elements.Static.N           = 1;
Elements.Static.R           = staticRadius;
Elements.Static.Position    = static;


end

