function all4point = renewvertebrae(solution,maxV,frontpoint,startpoint)
%RENEW 此处显示有关此函数的摘要
%   此处显示详细说明
endr = maxV*solution(1);
endzeta = solution(2);
endphi = solution(3);
endpoint = startpoint + [endr*cos(endzeta)*sin(endphi),endr*cos(endzeta)*cos(endphi),endr*sin(endzeta)];

secondpoint = startpoint + (startpoint-frontpoint)/norm(startpoint-frontpoint)*solution(4)*endr;

thirdr = solution(5)*endr;
thirdzeta = solution(6);
thirdphi = solution(7);
thirdpoint = startpoint + [thirdr*cos(thirdzeta)*sin(thirdphi),thirdr*cos(thirdzeta)*cos(thirdphi),thirdr*sin(thirdzeta)];

all4point = [startpoint,secondpoint,thirdpoint,endpoint];

end

