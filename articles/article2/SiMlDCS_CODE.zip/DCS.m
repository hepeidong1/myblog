function [GBCost,GBPosition,Curve] = DCS(VarMin,VarMax,nVar,nPop,MaxIt,CostFunction)

VarMin = VarMin.*ones(1,nVar);
VarMax = VarMax.*ones(1,nVar);
GeneratedPosition = zeros(nPop,nVar);
FeasiblePosition = zeros(nPop,nVar);
eta_qKR = zeros(1,nPop);
newCost = zeros(nPop,1);

Curve = zeros(1,MaxIt);

% Golden ratio
golden_ratio = 2/(1 + sqrt(5));

% High-performing individuals
ngS = max(6,round(nPop * (golden_ratio/3)));

% Initialize the population
Position = zeros(nPop,nVar);
for i = 1:nPop
    Position(i,:) = VarMin + rand(1,nVar) .* (VarMax - VarMin);
end

% Initialize fitness values
Cost = zeros(nPop,1);
for i = 1:nPop
    Cost(i,1) = CostFunction(Position(i,:));
end

% Generation
pc = 0.5; % probability constant

% Best solution
GBCost = min(Cost);

% Ranking-based self-improvement eq.8
phi_qKR = 0.25 + 0.55 * ((0 + ((1:nPop)/nPop)) .^ 0.5);

for it = 1:MaxIt

    % Sort population by fitness values
    [Position, Cost, ~] = PopSort(Position,Cost);
    GBindex = 1;
    lamda_t = 0.1 + (0.518 * ((1-(it/MaxIt)^0.5)));

    for i = 1:nPop
        eta_qKR(i) = (round(rand * phi_qKR(i)) + (rand <= phi_qKR(i)))/2;
        % eq.9
        jrand = floor(nVar * rand + 1);
        GeneratedPosition(i,:) = Position(i,:);
        if i == nPop && rand < pc 
            GeneratedPosition(i,:) = VarMin + rand * (VarMax - VarMin);
        elseif i <= ngS
            while true, r1 = round(nPop * rand + 0.5); if r1 ~= i && r1 ~= GBindex, break, end, end
            for d = 1:nVar % eq.19
                if rand <= eta_qKR(i) || d == jrand
                    GeneratedPosition(i,d) = Position(r1,d) + LnF3(golden_ratio,0.05,1,1);
                end
            end
        else
            while true, r1 = round(nPop * rand + 0.5); if r1 ~= i && r1 ~= GBindex, break, end, end
            while true, r2 = ngS + round((nPop - ngS) * rand + 0.5); if r2 ~= i && r2 ~= GBindex && r2 ~= r1, break, end, end
            omega_it = rand;
            for d = 1:nVar % eq.15
                if rand <= eta_qKR(i) || d == jrand
                    GeneratedPosition(i,d) = Position(GBindex,d) + ((Position(r2,d) - Position(i,d)) * lamda_t) + ((Position(r1,d) - Position(i,d)) * omega_it);
                end
            end
        end
        OutBoundary = GeneratedPosition(i,:) < VarMin;
        GeneratedPosition(i,OutBoundary) = 0.5*(GeneratedPosition(i,OutBoundary) + VarMin(OutBoundary));
        OutBoundary = GeneratedPosition(i,:) > VarMax;
        GeneratedPosition(i,OutBoundary) = 0.5*(GeneratedPosition(i,OutBoundary) + VarMax(OutBoundary));
        GeneratedPosition(i,:) = max(GeneratedPosition(i,:),VarMin);
        GeneratedPosition(i,:) = min(GeneratedPosition(i,:),VarMax);
        newCost(i,1) = CostFunction(GeneratedPosition(i,:));
        FeasiblePosition(i,:) = GeneratedPosition(i,:);
        if newCost(i,1) <= Cost(i,1) 
            Position(i,:) = FeasiblePosition(i,:); 
            Cost(i,1) = newCost(i,1);
            if newCost(i,1) < GBCost
                GBCost = newCost(i,1);
                GBindex = i;
            end
        end
    end
    Curve(it) = GBCost;
    GBPosition = Position(GBindex,:);
end
end

function [sorted_population, sorted_fitness, sorted_index] = PopSort(input_pop,input_fitness)
[sorted_fitness, sorted_index] = sort(input_fitness,1,'ascend');
sorted_population = input_pop(sorted_index,:);
end

function Y = LnF3(alpha, sigma, m, n)
Z = laplacernd(m, n);
Z = sign(rand(m,n)-0.5) .* Z;
U = rand(m, n);
R = sin(0.5*pi*alpha) .* tan(0.5*pi*(1-alpha*U)) - cos(0.5*pi*alpha);
Y = sigma * Z .* (R) .^ (1/alpha);
end

function x = laplacernd(m, n)
u1 = rand(m, n);
u2 = rand(m, n);
x = log(u1./u2);
end
