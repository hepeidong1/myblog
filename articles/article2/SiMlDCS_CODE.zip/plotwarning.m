function vertebraeface = plotwarning(lineinformation,color)
startpoint = lineinformation(1:3);
endpoint = lineinformation(4:6);
x = (0:20)/20 .*(endpoint(1) - startpoint(1)) + startpoint(1);
y = (0:20)/20 .*(endpoint(2) - startpoint(2)) + startpoint(2);
z = (0:20)/20 .*(endpoint(3) - startpoint(3)) + startpoint(3);

[ballx, bally, ballz] = sphere();
r = 3;
x(22) = x(21);
y(22) = y(21);
z(22) = z(21);
hold on

for i = 1:21
    vertebraeface(i) = surf(r*ballx+x(i),r*bally+y(i),r*ballz+z(i),'FaceColor',color,'EdgeColor','none','FaceAlpha',0.2);
end
end